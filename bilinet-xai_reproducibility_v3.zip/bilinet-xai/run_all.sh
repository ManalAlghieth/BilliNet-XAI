#!/usr/bin/env bash
# End-to-end reproduction of BiliNet-XAI.
#
# Before running:
#   1. Download all three datasets (see README "Data" section).
#   2. Edit the --image-col / --infant-col / --target-col / --fitz-col flags
#      in Step 1 to match the exact column names in each dataset's metadata CSV.
#      (For Mendeley, --target-col is the per-site TcB reading and --site-col the acquisition site.)
#   3. Activate the virtual environment:  source .venv/bin/activate
set -euo pipefail

NEO=data/NeoJaundice
MEN=data/Mendeley
FITZ=data/fitzpatrick17k

# ---------------------------------------------------------------------------
# Step 1 — Build manifests
# ---------------------------------------------------------------------------
# NeoJaundice (column names taken from the Figshare metadata)
python scripts/make_manifest.py \
    --meta "$NEO/metadata.csv" \
    --image-col image \
    --infant-col patient_id \
    --target-col tsb \
    --fitz-col fitzpatrick \
    --image-dir images \
    --out data/neojaundice_manifest.csv

# Mendeley — set the column names to those of the downloaded metadata (one row per image and site;
# --target-col is the TcB reading of that site, --site-col identifies forehead or sternum)
python scripts/make_manifest.py \
    --meta "$MEN/metadata.csv" \
    --image-col image \
    --infant-col infant_id \
    --target-col tcb \
    --site-col site \
    --tsb-col tsb \
    --image-dir images \
    --out data/mendeley_manifest.csv

# ---------------------------------------------------------------------------
# Step 2 — Infant-level splits (seed 42)
# ---------------------------------------------------------------------------
python scripts/make_splits.py --manifest data/neojaundice_manifest.csv --name neojaundice
python scripts/make_splits.py --manifest data/mendeley_manifest.csv    --name mendeley

# ---------------------------------------------------------------------------
# Step 3 — Spectral-branch pretraining on Fitzpatrick17k
# ---------------------------------------------------------------------------
python scripts/pretrain_fitzpatrick.py \
    --csv "$FITZ/fitzpatrick17k.csv" \
    --img-dir "$FITZ/images" \
    --out runs/fitz_pretrain

# ---------------------------------------------------------------------------
# Step 4 — Full BiliNet-XAI model, four initialization seeds
# ---------------------------------------------------------------------------
for s in 42 0 7 123; do
    python scripts/train.py \
        --manifest data/neojaundice_manifest.csv \
        --splits splits/neojaundice_splits.csv \
        --root "$NEO" \
        --variant full \
        --seed "$s" \
        --pretrained runs/fitz_pretrain/spectral.pt \
        --out "runs/full_seed$s"
done

# Test-split predictions of every seed (the seed-42 files in results/ are the primary checkpoint)
for s in 42 0 7 123; do
    python scripts/predict.py \
        --manifest data/neojaundice_manifest.csv \
        --splits splits/neojaundice_splits.csv \
        --root "$NEO" \
        --ckpt "runs/full_seed$s/final.pt" \
        --tag bilinet \
        --out "runs/full_seed$s"
done
python scripts/predict.py \
    --manifest data/neojaundice_manifest.csv \
    --splits splits/neojaundice_splits.csv \
    --root "$NEO" \
    --ckpt runs/full_seed42/final.pt \
    --tag bilinet \
    --latency \
    --out results

# Aggregate seed analysis (Section 4.1.1: MAE 0.89 ± 0.03, R² 0.96 ± 0.004)
python scripts/aggregate_seeds.py \
    --seeds 0 7 42 123 \
    --run-root runs \
    --out results

# ---------------------------------------------------------------------------
# Step 5 — Mendeley classification model (Table 4)
# ---------------------------------------------------------------------------
python scripts/train_mendeley.py \
    --manifest data/mendeley_manifest.csv \
    --splits splits/mendeley_splits.csv \
    --root "$MEN" \
    --label-site mean \
    --out runs/mendeley_cls

python scripts/predict_mendeley.py \
    --manifest data/mendeley_manifest.csv \
    --splits splits/mendeley_splits.csv \
    --root "$MEN" \
    --ckpt runs/mendeley_cls/mendeley_cls_final.pt \
    --label-site mean \
    --out results

# ---------------------------------------------------------------------------
# Step 6 — Ablation study (Table 5)
# ---------------------------------------------------------------------------
for v in spectral_only rgb_tokens spatial_only no_gating no_xai_reg; do
    python scripts/train.py \
        --manifest data/neojaundice_manifest.csv \
        --splits splits/neojaundice_splits.csv \
        --root "$NEO" \
        --variant "$v" \
        --pretrained runs/fitz_pretrain/spectral.pt \
        --out "runs/$v"
    python scripts/predict.py \
        --manifest data/neojaundice_manifest.csv \
        --splits splits/neojaundice_splits.csv \
        --root "$NEO" \
        --ckpt "runs/$v/final.pt" \
        --variant "$v" \
        --tag "$v" \
        --out results
done

# ---------------------------------------------------------------------------
# Step 7 — Baseline comparisons (Table 6)
# ---------------------------------------------------------------------------
for m in resnet50 densenet121 efficientnet_b4 vit_b16 swin_t \
         mobilenet_v3 inception_v3 vit_neojaundice eliazer_vit_kelm cmaf_net; do
    if [ "$m" = cmaf_net ] && ! python -c "import sys; sys.path.insert(0, 'scripts'); import baselines_custom as b; b.build_cmaf_net()" >/dev/null 2>&1; then
        echo "CMAF-Net: insert the adapted network in scripts/baselines_custom.py (see its docstring); skipped." >&2
        continue
    fi
    python scripts/train_baselines.py \
        --model "$m" \
        --manifest data/neojaundice_manifest.csv \
        --splits splits/neojaundice_splits.csv \
        --root "$NEO" \
        --out results
done

# ---------------------------------------------------------------------------
# Step 8 — Tables 3–8 and all figures
# ---------------------------------------------------------------------------
python scripts/stats_tables.py --results results
python scripts/plot_curves.py  --log runs/full_seed42/train_log.csv
python scripts/plot_curves.py  --fig3 --log runs/full_seed42/train_log.csv --log-mendeley runs/mendeley_cls/train_log_mendeley.csv
python scripts/explain_figure.py \
    --manifest data/neojaundice_manifest.csv \
    --splits splits/neojaundice_splits.csv \
    --root "$NEO" \
    --ckpt runs/full_seed42/final.pt \
    --ids 0008 0141 0335 0346 0386
python scripts/plot_tables.py --results results --figures-out figures

python scripts/count_complexity.py --all

# ---------------------------------------------------------------------------
# Step 9 (optional, RUN_EXTRA=1) — infant-level 5-fold cross-validation and zero-shot
# NeoJaundice -> Mendeley evaluation (future-work protocols, Section 5; not used for reported results)
# ---------------------------------------------------------------------------
if [ "${RUN_EXTRA:-0}" = 1 ]; then
    python scripts/kfold_cv.py --manifest data/neojaundice_manifest.csv --root "$NEO" \
        --pretrained runs/fitz_pretrain/spectral.pt --folds 5 --out results/kfold \
        --baselines resnet50 densenet121 efficientnet_b4 vit_b16 swin_t mobilenet_v3 inception_v3 \
                    vit_neojaundice eliazer_vit_kelm
    python scripts/zero_shot_mendeley.py --ckpt runs/full_seed42/final.pt \
        --manifest data/mendeley_manifest.csv --splits splits/mendeley_splits.csv --root "$MEN" \
        --baselines resnet50 densenet121 efficientnet_b4 vit_b16 swin_t mobilenet_v3 inception_v3 \
                    vit_neojaundice eliazer_vit_kelm \
        --baseline-ckpt-dir runs/baselines --out results/zero_shot
fi

echo "All steps complete. Results in results/tables/, figures in figures/."
