"""Fig. 4 (default) or Fig. 3 (--fig3) from the training logs; only training and validation curves are plotted.

  python scripts/plot_curves.py --log runs/full_seed42/train_log.csv                       # Fig. 4
  python scripts/plot_curves.py --fig3 --log runs/full_seed42/train_log.csv \\
      --log-mendeley runs/mendeley_cls/train_log_mendeley.csv                              # Fig. 3 (a) and (b)
"""
import argparse
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif"]})
ap = argparse.ArgumentParser()
ap.add_argument("--log", required=True, help="NeoJaundice train_log.csv")
ap.add_argument("--log-mendeley", help="train_log_mendeley.csv (needed with --fig3)")
ap.add_argument("--fig3", action="store_true")
ap.add_argument("--out", default=None)
a = ap.parse_args()
d = pd.read_csv(a.log)
if a.fig3:
    m = pd.read_csv(a.log_mendeley)
    fig, ax = plt.subplots(2, 1, figsize=(7.33, 5.0), sharex=True)
    ax[0].plot(d.epoch, d.train_MSE, label="Training Loss"); ax[0].plot(d.epoch, d.val_MSE, label="Validation Loss")
    ax[0].set_ylabel("MSE (mg$^2$/dL$^2$)")
    ax[1].plot(m.epoch, m.loss, label="Training Loss"); ax[1].plot(m.epoch, m.val_loss, label="Validation Loss")
    ax[1].set_ylabel("Cross-entropy Loss"); ax[1].set_xlabel("Epoch")
    for x, l in zip(ax, "ab"):
        x.legend(loc="upper right"); x.text(0.01, 0.95, f"({l})", transform=x.transAxes, fontweight="bold", va="top")
        x.spines[["top", "right"]].set_visible(False)
    out = a.out or "figures/fig3_loss_curves.png"; os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    fig.tight_layout(); fig.savefig(out, dpi=600)
else:
    fig, ax = plt.subplots(2, 1, figsize=(7.33, 4.4), sharex=True)
    ax[0].plot(d.epoch, d.train_R2, label="Train R$^2$"); ax[0].plot(d.epoch, d.val_R2, label="Val R$^2$")
    ax[1].plot(d.epoch, d.train_MAE, label="Train MAE"); ax[1].plot(d.epoch, d.val_MAE, label="Val MAE")
    ax[0].set_ylabel("R$^2$"); ax[1].set_ylabel("MAE (mg/dL)"); ax[1].set_xlabel("Epoch")
    for x, l in zip(ax, "ab"):
        x.legend(loc="lower right" if l == "a" else "upper right", frameon=False)
        x.text(-0.08, 1.0, f"({l})", transform=x.transAxes, fontweight="bold", va="top")
        x.spines[["top", "right"]].set_visible(False)
    out = a.out or "figures/fig4_convergence.png"; os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    fig.tight_layout(); fig.savefig(out, dpi=600)
