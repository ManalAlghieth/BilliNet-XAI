# Prediction files and recomputed tables

## NeoJaundice (regression + classification)

`scripts/predict.py` and `scripts/train_baselines.py` write, for every model tag:

* `<tag>_test_image_predictions.csv`: image_path, infant_id, fitzpatrick_group, site, y_true, y_pred (mg/dL)
* `<tag>_test_infant_predictions.csv`: infant_id, fitzpatrick_group, y_true, y_pred (mean of the infant's three images)

`scripts/stats_tables.py` reads them and writes:

| Output file | Paper table |
|---|---|
| `tables/table3_per_class.csv` | Table 3 — NeoJaundice per-class classification |
| `tables/table5_ablation.csv` | Table 5 — Ablation study |
| `tables/table6_baselines.csv` | Table 6 — Baseline comparison |
| `tables/table7_fitzpatrick.csv` | Table 7 — Fitzpatrick stratification |

`scripts/aggregate_seeds.py` reads `runs/full_seed{0,7,42,123}/bilinet_test_infant_predictions.csv` and writes `seed_analysis_per_seed.csv`, `seed_analysis_summary.csv` (mean ± SD across seeds) and `bilinet_ensemble_infant_predictions.csv` into `results/`.

## Mendeley (classification)

`scripts/predict_mendeley.py` writes:

* `mendeley_bilinet_test_image_predictions.csv`: image_path, infant_id, site, y_true_class, y_pred_class, y_pred_logits
* `mendeley_bilinet_test_infant_predictions.csv`: infant_id, y_true_class, y_pred_class (majority vote over the infant's images; not used for Table 4)

`scripts/predict_mendeley.py` also writes `mendeley_confusion_matrix.csv` and `figures/mendeley_confusion_matrix.png` (Fig. 5b) and `figures/mendeley_roc.png` (Fig. 6b).

`scripts/stats_tables.py` writes `tables/table4_mendeley.csv` (Table 4: image-level per-class precision, recall, F1, one-vs-rest AUC and n, with the support-weighted average).

## Generated files

All prediction files, tables, logs and figures are produced by running `run_all.sh`; `predict.py --latency` also writes `efficiency_metrics.csv` (parameters in millions and batch-1 latency), which `stats_tables.py` copies to `tables/table8_efficiency.csv`.

## Additional outputs

* `tables/table5_ablation.csv` and `tables/table6_baselines.csv` contain a first row for BiliNet-XAI
  (`method = bilinet`), the paired Wilcoxon p-values (raw and Bonferroni-corrected), the matched-pairs
  rank-biserial r, the BCa 95% interval on the MAE difference and, for each model, the image-level
  four-class accuracy (%) and weighted F1 obtained by thresholding the regression output.
* `tables/neojaundice_confusion_matrix.csv` and `figures/neojaundice_confusion_matrix.png` (Fig. 5a).
* `results/kfold/` and `results/zero_shot/` are written only by the optional Step 9.
