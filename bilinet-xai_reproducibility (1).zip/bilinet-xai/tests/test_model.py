"""Shape, gradient and statistics checks. Run: python -m pytest -q tests"""
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from bilinet.explain import band_importance, gradcam_pp  # noqa: E402
from bilinet.losses import total_loss  # noqa: E402
from bilinet.metrics import regression, wilcoxon_paired  # noqa: E402
from bilinet.model import TABLE4_VARIANTS, build_model, count_params  # noqa: E402


def test_variants_forward():
    x = torch.randn(2, 3, 224, 224)
    for v in TABLE4_VARIANTS:
        assert build_model(v)(x).shape == (2,)


def test_gradcampp_and_band_importance():
    m = build_model("full").eval()
    out = m(torch.randn(2, 3, 224, 224), return_all=True)
    cam = gradcam_pp(out["y"], out["cam_maps"])
    assert cam.shape == (2, 14, 14) and (cam >= 0).all()
    imp = band_importance(out["y"], out["spectral_tokens"])
    assert imp.shape == (2, 16) and torch.allclose(imp.sum(1), torch.ones(2), atol=1e-5)


def test_training_step_with_xai_loss():
    m = build_model("full")
    out = m(torch.randn(2, 3, 224, 224), return_all=True)
    loss, parts = total_loss(out, torch.tensor([8.0, 14.0]))
    loss.backward()
    assert parts["xai"] > 0
    assert m.aux.weight.grad is not None and m.spat.embed.weight.grad.abs().sum() > 0


def test_infant_averaging_lowers_mae():
    rng = np.random.default_rng(0)
    y = np.repeat(rng.uniform(2, 22, 100), 3)
    p = y + rng.normal(0, 1, 300)
    img = regression(y, p)["MAE"]
    inf = regression(y.reshape(-1, 3).mean(1), p.reshape(-1, 3).mean(1))["MAE"]
    assert inf < img


def test_wilcoxon_rank_biserial_sign():
    a, b = np.full(50, 0.5) + np.linspace(0, .1, 50), np.full(50, 1.0) + np.linspace(0, .1, 50)
    p, r = wilcoxon_paired(a, b)
    assert p < 0.001 and r > 0.9


if __name__ == "__main__":
    print({v: round(count_params(build_model(v)) / 1e6, 2) for v in TABLE4_VARIANTS})
