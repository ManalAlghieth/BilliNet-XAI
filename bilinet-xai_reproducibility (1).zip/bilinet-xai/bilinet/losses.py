"""Training objective, Eqs. (20)-(23) and the L_xai saliency-entropy term."""
import torch
import torch.nn.functional as F
from .explain import gradcam_pp


def spectral_consistency(gates):
    """Eq. (22): mean squared deviation of each band gate from its batch mean, averaged over layers."""
    if not gates:
        return torch.zeros(())
    loss = 0.0
    for g in gates:                                   # g: (B, C_s)
        loss = loss + (g - g.mean(0, keepdim=True)).pow(2).mean()
    return loss / len(gates)


def saliency_entropy(cam, eps=1e-8):
    """L_xai: entropy of the L1-normalized spatial Grad-CAM++ map, averaged over the batch."""
    p = cam.flatten(1)
    p = p / (p.sum(1, keepdim=True) + eps)
    hw = p.shape[1]
    return (-(p * torch.log(p + eps)).sum(1) / hw).mean()


def total_loss(out, y, lambdas=(1.0, 0.5, 0.1, 0.05), delta=1.5):
    """Eq. (23). Returns (loss, dict of components). lambda_4 = 0 disables L_xai (Table 4 'No XAI Reg.')."""
    l1, l2, l3, l4 = lambdas
    pred = out["y"]
    mse = F.mse_loss(pred, y)                                                  # Eq. (20)
    hub = F.huber_loss(pred, y, delta=delta)                                   # Eq. (21)
    spec = spectral_consistency(out.get("gates", [])).to(pred.device)
    xai = torch.zeros((), device=pred.device)
    if l4 > 0 and "cam_maps" in out:
        cam = gradcam_pp(pred, out["cam_maps"], create_graph=True)            # spatial branch only
        xai = saliency_entropy(cam)
    loss = l1 * mse + l2 * hub + l3 * spec + l4 * xai
    return loss, {"mse": mse.item(), "huber": hub.item(), "spec": float(spec), "xai": float(xai)}
