"""BiliNet XAI model (manuscript Sections 3.2 to 3.6).

Equation numbers in comments refer to the manuscript.
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class SpectralPreprocessing(nn.Module):
    """Eqs. (1)-(2): learned RGB -> C_s pseudo-spectral projection, channel mask, LayerNorm.

    The C_s bands are learned linear combinations of the three RGB channels and carry no
    wavelength information. Each band map is pooled to one token of length d_s.
    """

    def __init__(self, c_s=16, d_s=256, rgb_tokens=False):
        super().__init__()
        self.rgb_tokens = rgb_tokens
        self.proj = None if rgb_tokens else nn.Conv2d(3, c_s, kernel_size=1)   # W_s, b_s (Eq. 1)
        n_tok = 3 if rgb_tokens else c_s
        self.mask = nn.Parameter(torch.ones(n_tok, 1))                         # M_lambda (Eq. 2)
        side = math.isqrt(d_s)
        assert side * side == d_s, "d_s must be a perfect square"
        self.side = side
        self.norm = nn.LayerNorm(d_s)

    def forward(self, x):
        s = x if self.rgb_tokens else F.gelu(self.proj(x))                    # (B, C_s, H, W)
        s = F.adaptive_avg_pool2d(s, self.side).flatten(2)                     # (B, C_s, d_s)
        return self.norm(s * self.mask)                                        # F_s^(0)


class SpectralAttentionLayer(nn.Module):
    """Eqs. (3)-(9): multi-head spectral self-attention, learnable temperature, band gating."""

    def __init__(self, c_s=16, d_s=256, heads=8, ffn_dim=2048, dropout=0.1):
        super().__init__()
        self.h, self.dk = heads, d_s // heads
        self.qkv = nn.Linear(d_s, 3 * d_s)                                     # W_Q, W_K, W_V (Eq. 3)
        self.out = nn.Linear(d_s, d_s)                                         # W_O (Eq. 5)
        self.log_tau = nn.Parameter(torch.zeros(1))                            # tau_lambda > 0 (Eq. 4)
        self.gate = nn.Linear(c_s, c_s)                                        # W_g, b_g (Eq. 6)
        self.ffn = nn.Sequential(nn.Linear(d_s, ffn_dim), nn.GELU(), nn.Dropout(dropout),
                                 nn.Linear(ffn_dim, d_s))                     # Eq. (9)
        self.norm = nn.LayerNorm(d_s)
        self.drop = nn.Dropout(dropout)

    def forward(self, f):
        b, n, d = f.shape
        q, k, v = self.qkv(f).view(b, n, 3, self.h, self.dk).permute(2, 0, 3, 1, 4)
        tau = self.log_tau.exp()
        a = torch.softmax(q @ k.transpose(-2, -1) / (math.sqrt(self.dk) * tau), dim=-1)
        mhsa = self.out((self.drop(a) @ v).transpose(1, 2).reshape(b, n, d))
        g = torch.sigmoid(self.gate(mhsa.mean(dim=-1)))                       # one gate per band (Eq. 6)
        z = g.unsqueeze(-1) * mhsa                                             # Eq. (7)
        return self.norm(z + self.ffn(z)) + f, g                               # Eq. (8)


def sinusoidal(n, d):
    """Eq. (12)."""
    pos = torch.arange(n).unsqueeze(1).float()
    div = torch.exp(torch.arange(0, d, 2).float() * (-math.log(10000.0) / d))
    pe = torch.zeros(n, d)
    pe[:, 0::2] = torch.sin(pos * div)
    pe[:, 1::2] = torch.cos(pos * div)
    return pe


class SpatialEncoder(nn.Module):
    """Eqs. (10)-(15): patch embedding, positional dermal encoding, transformer layers."""

    def __init__(self, img=224, patch=16, d_p=256, layers=4, heads=8, ffn_dim=2048, dropout=0.1):
        super().__init__()
        n = (img // patch) ** 2
        self.embed = nn.Conv2d(3, d_p, kernel_size=patch, stride=patch)       # W_p, b_p (Eq. 10)
        self.register_buffer("pe", sinusoidal(n, d_p))                         # p_i (Eq. 12)
        self.dermal = nn.Parameter(torch.zeros(n, d_p))                        # d_i (Eq. 11)
        self.alpha = nn.Parameter(torch.tensor(1.0))                           # alpha_d (Eq. 11)
        nn.init.trunc_normal_(self.dermal, std=0.02)
        layer = nn.TransformerEncoderLayer(d_p, heads, ffn_dim, dropout, activation="gelu",
                                           batch_first=True, norm_first=True)
        self.enc = nn.TransformerEncoder(layer, layers, enable_nested_tensor=False)

    def forward(self, x):
        e = self.embed(x).flatten(2).transpose(1, 2)                           # (B, N_p, d_p)
        return self.enc(e + self.pe + self.alpha * self.dermal)                # Eq. (13), F_p^(L_p)


class GatedFusion(nn.Module):
    """Eqs. (16)-(18): cross-modal sigmoid gates of length d_f applied by Hadamard product."""

    def __init__(self, d_s=256, d_p=256, d_f=256):
        super().__init__()
        self.sp = nn.Linear(d_s + d_p, d_f)
        self.ps = nn.Linear(d_p + d_s, d_f)
        self.ws = nn.Linear(d_s, d_f, bias=False)                              # W_s'
        self.wp = nn.Linear(d_p, d_f, bias=False)                              # W_p'

    def forward(self, zs, zp):
        c_sp = torch.sigmoid(self.sp(torch.cat([zs, zp], -1)))
        c_ps = torch.sigmoid(self.ps(torch.cat([zp, zs], -1)))
        return c_sp * self.ws(zs) + c_ps * self.wp(zp)


class BiliNetXAI(nn.Module):
    """Full model and the Table 4 variants.

    branches: "both" | "spectral" | "spatial".  rgb_tokens=True gives the RGB-token ablation (C_s = 3,
    no learned projection).  gating=False replaces gated fusion by concatenation plus a linear layer.

    The auxiliary 1x1 convolution on the spatial branch (Section 3.8) produces the Grad-CAM++
    target maps A^k on the 14 x 14 token grid. It is identity-initialized and z_p is pooled from its
    output, so that the gradients of y_hat with respect to A^k used by Grad-CAM++ are defined.
    """

    def __init__(self, img=224, patch=16, c_s=16, d=256, d_f=256, heads=8, layers=4,
                 ffn_dim=2048, dropout=0.1, branches="both", gating=True, rgb_tokens=False):
        super().__init__()
        self.branches, self.gating = branches, gating
        self.use_spec = branches in ("both", "spectral")
        self.use_spat = branches in ("both", "spatial")
        n_tok = 3 if rgb_tokens else c_s
        if self.use_spec:
            self.pre = SpectralPreprocessing(c_s, d, rgb_tokens)
            self.spec = nn.ModuleList([SpectralAttentionLayer(n_tok, d, heads, ffn_dim, dropout)
                                       for _ in range(layers)])
        if self.use_spat:
            self.spat = SpatialEncoder(img, patch, d, layers, heads, ffn_dim, dropout)
            self.aux = nn.Conv2d(d, d, kernel_size=1)
            with torch.no_grad():
                self.aux.weight.copy_(torch.eye(d).view(d, d, 1, 1))
                self.aux.bias.zero_()
        if branches == "both":
            self.fuse = GatedFusion(d, d, d_f) if gating else nn.Linear(2 * d, d_f)
            head_in = d_f
        else:
            head_in = d
        self.head = nn.Sequential(nn.Linear(head_in, 128), nn.ReLU(), nn.Linear(128, 64), nn.ReLU(),
                                  nn.Linear(64, 1))                             # Eq. (19)

    def forward(self, x, return_all=False):
        out, feats = {}, []
        if self.use_spec:
            fs = self.pre(x)
            gates = []
            for layer in self.spec:
                fs, g = layer(fs)
                gates.append(g)
            out["spectral_tokens"], out["gates"] = fs, gates
            feats.append(fs.mean(1))                                           # z_s
        if self.use_spat:
            fp = self.spat(x)
            b, n, d = fp.shape
            grid = math.isqrt(n)
            a = self.aux(fp.transpose(1, 2).reshape(b, d, grid, grid))         # A^k
            out["cam_maps"] = a
            feats.append(a.mean((2, 3)))                                       # z_p
        if self.branches == "both":
            zf = self.fuse(*feats) if self.gating else self.fuse(torch.cat(feats, -1))
        else:
            zf = feats[0]
        out["y"] = self.head(zf).squeeze(-1)
        return out if return_all else out["y"]


TABLE4_VARIANTS = {
    "full": dict(),
    "spectral_only": dict(branches="spectral"),
    "rgb_tokens": dict(branches="spectral", rgb_tokens=True),
    "spatial_only": dict(branches="spatial"),
    "no_gating": dict(gating=False),
    "no_xai_reg": dict(),          # same architecture as "full", trained with lambda_4 = 0
}


def build_model(variant="full", **kw):
    return BiliNetXAI(**{**TABLE4_VARIANTS[variant], **kw})


def count_params(m):
    return sum(p.numel() for p in m.parameters() if p.requires_grad)
