"""BiliNet XAI: dual-branch spectral-spatial attention transformer for neonatal bilirubin estimation."""
__version__ = "1.0.0"
