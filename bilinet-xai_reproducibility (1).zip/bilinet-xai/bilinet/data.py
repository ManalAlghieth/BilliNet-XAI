"""Datasets, transforms, severity classes and infant-level aggregation.

All scripts work from a manifest CSV with one row per image and the columns
    image_path, infant_id, target            (required)
    fitzpatrick_group, site                   (optional)
`target` is TSB in mg/dL for NeoJaundice and the TcB reading for Mendeley.
"""
import pandas as pd
import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms as T

from .constants import CLASSES, THRESHOLDS, infant_level, severity  # noqa: F401

MEAN, STD = (0.485, 0.456, 0.406), (0.229, 0.224, 0.225)


def train_tf(size=224):
    # Geometric augmentation only: colour jitter would alter the chromatic signal being estimated.
    return T.Compose([T.Resize((size, size)), T.RandomHorizontalFlip(), T.RandomRotation(10),
                      T.ToTensor(), T.Normalize(MEAN, STD)])


def eval_tf(size=224):
    return T.Compose([T.Resize((size, size)), T.ToTensor(), T.Normalize(MEAN, STD)])


class ImageTable(Dataset):
    def __init__(self, df, root=".", tf=None):
        self.df, self.root, self.tf = df.reset_index(drop=True), root, tf or eval_tf()

    def __len__(self):
        return len(self.df)

    def __getitem__(self, i):
        r = self.df.iloc[i]
        img = Image.open(f"{self.root}/{r.image_path}").convert("RGB")
        return self.tf(img), torch.tensor(float(r.target)), i


def load_split(manifest, split_csv, split):
    m = pd.read_csv(manifest)
    s = pd.read_csv(split_csv)
    ids = set(s.loc[s.split == split, "infant_id"].astype(str))
    return m[m.infant_id.astype(str).isin(ids)].copy()
