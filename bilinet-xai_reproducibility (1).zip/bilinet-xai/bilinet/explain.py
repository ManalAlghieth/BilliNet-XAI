"""Grad-CAM++ on the spatial branch (Eqs. 24-26) and band-level spectral importance (Section 3.8).

Grad-CAM++ uses the closed form of Chattopadhay et al. (2018) under the exponential-output
assumption, in which second and third derivatives are expressed through powers of the first
derivative. With create_graph=True the map is differentiable, which is required for L_xai.
"""
import torch
import torch.nn.functional as F


def gradcam_pp(y, maps, create_graph=False):
    """y: (B,) predictions; maps: (B, K, h, w) target feature maps A^k that y depends on.

    Returns S_cam of shape (B, h, w), Eq. (26).
    """
    g = torch.autograd.grad(y.sum(), maps, create_graph=create_graph, retain_graph=True)[0]
    g2, g3 = g.pow(2), g.pow(3)
    denom = 2 * g2 + (maps * g3).sum((2, 3), keepdim=True)
    denom = torch.where(denom != 0, denom, torch.ones_like(denom))
    alpha = g2 / denom                                                        # Eq. (24)
    w = (alpha * F.relu(g)).sum((2, 3), keepdim=True)                         # Eq. (25)
    return F.relu((w * maps).sum(1))                                          # Eq. (26)


def upsample(cam, size=224):
    """Bilinear upsampling of the 14 x 14 map to input resolution, min-max scaled for display only."""
    c = F.interpolate(cam.unsqueeze(1), size=(size, size), mode="bilinear", align_corners=False).squeeze(1)
    lo = c.flatten(1).min(1)[0].view(-1, 1, 1)
    hi = c.flatten(1).max(1)[0].view(-1, 1, 1)
    return (c - lo) / (hi - lo + 1e-8)


def band_importance(y, spectral_tokens):
    """I_c = ||dy/dF_s[c,:]||_1 / sum_c' ||dy/dF_s[c',:]||_1 over the C_s pseudo-spectral tokens.

    Returns (B, C_s). Carries no spatial information.
    """
    g = torch.autograd.grad(y.sum(), spectral_tokens, retain_graph=True)[0].abs().sum(-1)
    return g / (g.sum(-1, keepdim=True) + 1e-12)
