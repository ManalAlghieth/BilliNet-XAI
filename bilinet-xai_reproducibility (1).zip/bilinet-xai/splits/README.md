# Split index files

`scripts/make_splits.py` writes one file per dataset:

| File | Columns | Content |
|---|---|---|
| `neojaundice_splits.csv` | infant_id, split, severity | 521 train, 112 val, 112 test infants |
| `mendeley_splits.csv` | infant_id, split, severity | 210 train, 45 val, 45 test infants |
| `fitz17k_subset.csv` | md5hash, fitzpatrick_scale | the 9,847 Fitzpatrick17k images used for pretraining |

`split` is one of train, val, test. `severity` is the stratification class (0 Normal, 1 Mild, 2 Moderate, 3 Severe).
Infant identifiers are those of the original dataset metadata, so the files can be joined to the public releases.
