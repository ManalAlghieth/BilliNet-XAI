#!/usr/bin/env bash
# End-to-end reproduction. Edit the column names in step 1 to match the downloaded metadata files.
set -euo pipefail
NEO=data/NeoJaundice; MEN=data/Mendeley; FITZ=data/fitzpatrick17k

# 1. Manifests (see README, "Data")
python scripts/make_manifest.py --meta $NEO/metadata.csv --image-col image --infant-col patient_id \
    --target-col tsb --fitz-col fitzpatrick --image-dir images --out data/neojaundice_manifest.csv
python scripts/make_manifest.py --meta $MEN/metadata.csv --image-col image --infant-col infant_id \
    --target-col tcb --site-col site --image-dir images --out data/mendeley_manifest.csv

# 2. Infant-level splits, seed 42
python scripts/make_splits.py --manifest data/neojaundice_manifest.csv --name neojaundice
python scripts/make_splits.py --manifest data/mendeley_manifest.csv --name mendeley

# 3. Spectral-branch pretraining on Fitzpatrick17k
python scripts/pretrain_fitzpatrick.py --csv $FITZ/fitzpatrick17k.csv --img-dir $FITZ/images --out runs/fitz_pretrain

# 4. Full model, four initialization seeds
for s in 42 0 7 123; do
  python scripts/train.py --manifest data/neojaundice_manifest.csv --splits splits/neojaundice_splits.csv \
      --root $NEO --variant full --seed $s --pretrained runs/fitz_pretrain/spectral.pt --out runs/full_seed$s
done
python scripts/predict.py --manifest data/neojaundice_manifest.csv --splits splits/neojaundice_splits.csv \
    --root $NEO --ckpt runs/full_seed42/final.pt --tag bilinet --latency --out results

# 5. Ablations (Table 4)
for v in spectral_only rgb_tokens spatial_only no_gating no_xai_reg; do
  python scripts/train.py --manifest data/neojaundice_manifest.csv --splits splits/neojaundice_splits.csv \
      --root $NEO --variant $v --pretrained runs/fitz_pretrain/spectral.pt --out runs/$v
  python scripts/predict.py --manifest data/neojaundice_manifest.csv --splits splits/neojaundice_splits.csv \
      --root $NEO --ckpt runs/$v/final.pt --variant $v --tag $v --out results
done

# 6. Baselines (Table 5)
for m in resnet50 densenet121 efficientnet_b4 vit_b16 swin_t mobilenet_v3 inception_v3 vit_neojaundice eliazer_vit_kelm cmaf_net; do
  python scripts/train_baselines.py --model $m --manifest data/neojaundice_manifest.csv \
      --splits splits/neojaundice_splits.csv --root $NEO --out results
done

# 7. Tables 3-6, figures
python scripts/stats_tables.py --results results
python scripts/plot_curves.py --log runs/full_seed42/train_log.csv
python scripts/explain_figure.py --manifest data/neojaundice_manifest.csv --splits splits/neojaundice_splits.csv \
    --root $NEO --ckpt runs/full_seed42/final.pt --ids 0008 0141 0335 0346 0386
python scripts/plot_tables.py
