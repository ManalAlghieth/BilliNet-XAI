# Prediction files

`scripts/predict.py` and `scripts/train_baselines.py` write, for every model tag:

* `<tag>_test_image_predictions.csv`: image_path, infant_id, fitzpatrick_group, site, y_true, y_pred (mg/dL)
* `<tag>_test_infant_predictions.csv`: infant_id, fitzpatrick_group, y_true, y_pred (mean of the infant's images)

`scripts/stats_tables.py` reads them and writes `tables/table3_per_class.csv`, `table4_ablation.csv`,
`table5_baselines.csv` and `table6_fitzpatrick.csv`.
