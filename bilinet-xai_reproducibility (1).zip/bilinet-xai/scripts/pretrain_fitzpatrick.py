"""Pretrain the spectral branch on Fitzpatrick17k phototype classification (Section 4.1).

Protocol: 9,847 images spanning phototypes I to VI, 224 x 224, six-class cross-entropy,
AdamW lr 1e-4, 50 epochs. Only the spectral preprocessing and spectral encoder are trained and
saved; Fitzpatrick17k is not used for any evaluation.

If an image list is given with --subset, exactly those images are used. Otherwise a subset of
--n images is drawn with seed 42, stratified by phototype, and written to splits/fitz17k_subset.csv.

  python scripts/pretrain_fitzpatrick.py --csv data/fitzpatrick17k.csv --img-dir data/fitz17k \
      --out runs/fitz_pretrain
"""
import argparse
import os
import sys

import pandas as pd
import torch
import torch.nn as nn
from PIL import Image
from torch.utils.data import DataLoader, Dataset

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from bilinet.data import train_tf  # noqa: E402
from bilinet.model import SpectralAttentionLayer, SpectralPreprocessing  # noqa: E402


class SpectralClassifier(nn.Module):
    def __init__(self, c_s=16, d=256, heads=8, layers=4, ffn_dim=2048, n_cls=6):
        super().__init__()
        self.pre = SpectralPreprocessing(c_s, d)
        self.spec = nn.ModuleList([SpectralAttentionLayer(c_s, d, heads, ffn_dim) for _ in range(layers)])
        self.cls = nn.Linear(d, n_cls)

    def forward(self, x):
        f = self.pre(x)
        for layer in self.spec:
            f, _ = layer(f)
        return self.cls(f.mean(1))


class Fitz(Dataset):
    def __init__(self, df, img_dir, tf):
        self.df, self.dir, self.tf = df.reset_index(drop=True), img_dir, tf

    def __len__(self):
        return len(self.df)

    def __getitem__(self, i):
        r = self.df.iloc[i]
        return self.tf(Image.open(f"{self.dir}/{r.md5hash}.jpg").convert("RGB")), int(r.fitzpatrick_scale) - 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True, help="fitzpatrick17k.csv (columns md5hash, fitzpatrick_scale)")
    ap.add_argument("--img-dir", required=True)
    ap.add_argument("--subset", help="CSV with an md5hash column listing the exact pretraining images")
    ap.add_argument("--n", type=int, default=9847)
    ap.add_argument("--epochs", type=int, default=50)
    ap.add_argument("--bs", type=int, default=64)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    torch.manual_seed(42)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    df = pd.read_csv(a.csv)
    df = df[df.fitzpatrick_scale.between(1, 6)]
    df = df[df.md5hash.map(lambda h: os.path.exists(f"{a.img_dir}/{h}.jpg"))]
    if a.subset:
        df = df[df.md5hash.isin(pd.read_csv(a.subset).md5hash)]
    else:
        frac = min(1.0, a.n / len(df))
        df = df.groupby("fitzpatrick_scale", group_keys=False).sample(frac=frac, random_state=42)
        os.makedirs("splits", exist_ok=True)
        df[["md5hash", "fitzpatrick_scale"]].to_csv("splits/fitz17k_subset.csv", index=False)
    print(f"pretraining images: {len(df)}", df.fitzpatrick_scale.value_counts().sort_index().to_dict())

    model = SpectralClassifier().to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-4)
    dl = DataLoader(Fitz(df, a.img_dir, train_tf()), a.bs, shuffle=True, num_workers=8)
    for ep in range(1, a.epochs + 1):
        model.train(); tot = 0.0
        for x, y in dl:
            loss = nn.functional.cross_entropy(model(x.to(dev)), y.to(dev))
            opt.zero_grad(); loss.backward(); opt.step(); tot += loss.item()
        print(f"ep {ep} loss {tot / len(dl):.4f}")
    os.makedirs(a.out, exist_ok=True)
    sd = {k: v for k, v in model.state_dict().items() if k.startswith(("pre.", "spec."))}
    torch.save(sd, f"{a.out}/spectral.pt")


if __name__ == "__main__":
    main()
