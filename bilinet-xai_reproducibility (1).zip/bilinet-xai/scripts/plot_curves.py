"""Fig. 4 from train_log.csv (training and validation curves only; no test values are plotted)."""
import argparse
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif"]})
ap = argparse.ArgumentParser()
ap.add_argument("--log", required=True)
ap.add_argument("--out", default="figures/fig4_convergence.png")
a = ap.parse_args()
d = pd.read_csv(a.log)
fig, ax = plt.subplots(2, 1, figsize=(7.33, 4.4), sharex=True)
ax[0].plot(d.epoch, d.train_R2, label="Train R$^2$"); ax[0].plot(d.epoch, d.val_R2, label="Val R$^2$")
ax[1].plot(d.epoch, d.train_MAE, label="Train MAE"); ax[1].plot(d.epoch, d.val_MAE, label="Val MAE")
ax[0].set_ylabel("R$^2$"); ax[1].set_ylabel("MAE (mg/dL)"); ax[1].set_xlabel("Epoch")
for x, l in zip(ax, "ab"):
    x.legend(loc="lower right" if l == "a" else "upper right", frameon=False)
    x.text(-0.08, 1.0, f"({l})", transform=x.transAxes, fontweight="bold", va="top")
    x.spines[["top", "right"]].set_visible(False)
fig.tight_layout(); fig.savefig(a.out, dpi=600)
