"""Infant-level 70/15/15 split stratified by severity class, seed 42 (Section 4.1).

Each infant is assigned to exactly one split, so all of its images stay together.
Writes splits/<name>_splits.csv with columns infant_id, split, severity.

  python scripts/make_splits.py --manifest data/neojaundice_manifest.csv --name neojaundice
  python scripts/make_splits.py --manifest data/mendeley_manifest.csv   --name mendeley
"""
import argparse
import os
import sys

import pandas as pd
from sklearn.model_selection import train_test_split

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from bilinet.constants import severity  # noqa: E402


def make(manifest, seed=42, val=0.15, test=0.15):
    m = pd.read_csv(manifest)
    inf = m.groupby("infant_id", as_index=False).target.mean()
    inf["severity"] = severity(inf.target)
    n = len(inf)
    n_test, n_val = round(n * test), round(n * val)
    trval, te = train_test_split(inf, test_size=n_test, stratify=inf.severity, random_state=seed)
    tr, va = train_test_split(trval, test_size=n_val, stratify=trval.severity, random_state=seed)
    out = pd.concat([tr.assign(split="train"), va.assign(split="val"), te.assign(split="test")])
    return out[["infant_id", "split", "severity"]].sort_values(["split", "infant_id"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--name", required=True)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--outdir", default="splits")
    a = ap.parse_args()
    s = make(a.manifest, a.seed)
    os.makedirs(a.outdir, exist_ok=True)
    path = f"{a.outdir}/{a.name}_splits.csv"
    s.to_csv(path, index=False)
    m = pd.read_csv(a.manifest).merge(s, on="infant_id")
    print(path)
    print(m.groupby("split").agg(infants=("infant_id", "nunique"), images=("image_path", "size")))


if __name__ == "__main__":
    main()
