"""Recompute Tables 3 to 6 from prediction files written by predict.py.

Expected files in --results (tag names are configurable):
  bilinet_test_{image,infant}_predictions.csv
  <ablation tag>_test_infant_predictions.csv      for the Table 4 variants
  <baseline tag>_test_infant_predictions.csv      for the Table 5 baselines

  python scripts/stats_tables.py --results results
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from bilinet.constants import CLASSES, severity  # noqa: E402
from bilinet.metrics import (bca_ci_mean_diff, bonferroni, bootstrap_ci_mae, classification,  # noqa: E402
                             regression, wilcoxon_paired)

ABLATIONS = ["spectral_only", "rgb_tokens", "spatial_only", "no_gating", "no_xai_reg"]
BASELINES = ["resnet50", "densenet121", "efficientnet_b4", "vit_b16", "swin_t", "mobilenet_v3",
             "inception_v3", "cmaf_net", "vit_neojaundice", "eliazer_vit_kelm"]


def load(res, tag, level):
    p = f"{res}/{tag}_test_{level}_predictions.csv"
    return pd.read_csv(p) if os.path.exists(p) else None


def paired_rows(ref, others, m):
    rows = []
    a = ref.set_index("infant_id")
    for tag, df in others.items():
        b = df.set_index("infant_id").loc[a.index]
        ea, eb = (a.y_true - a.y_pred).abs().values, (b.y_true - b.y_pred).abs().values
        p, r = wilcoxon_paired(ea, eb)
        lo, hi = bca_ci_mean_diff(ea, eb)
        rows.append({"method": tag, **{k: round(v, 3) for k, v in regression(b.y_true, b.y_pred).items()},
                     "p_raw": p, "p_bonferroni": bonferroni(p, m), "rank_biserial_r": round(r, 2),
                     "CI95_dMAE_low": round(lo, 2), "CI95_dMAE_high": round(hi, 2)})
    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    a = ap.parse_args()
    out = f"{a.results}/tables"
    os.makedirs(out, exist_ok=True)
    img, inf = load(a.results, "bilinet", "image"), load(a.results, "bilinet", "infant")

    # Headline (infant level, Tables 4 and 5)
    head = regression(inf.y_true, inf.y_pred)
    print("BiliNet XAI infant level:", {k: round(v, 3) for k, v in head.items()})

    # Table 3: four-class severity from the regression output
    yc, pc = severity(img.y_true), severity(img.y_pred)
    c = classification(yc, pc)
    t3 = pd.DataFrame({"class": CLASSES, **{k: np.round(v, 2) for k, v in c["per_class"].items()}})
    t3.to_csv(f"{out}/table3_per_class.csv", index=False)
    print(f"Table 3 accuracy {c['Accuracy']:.3f}")

    # Table 4: ablations, Bonferroni over the number of available variants (five in the manuscript)
    abl = {t: load(a.results, t, "infant") for t in ABLATIONS}
    abl = {t: d for t, d in abl.items() if d is not None}
    if abl:
        paired_rows(inf, abl, len(abl)).to_csv(f"{out}/table4_ablation.csv", index=False)

    # Table 5: ten baselines, Bonferroni m = 10
    base = {t: load(a.results, t, "infant") for t in BASELINES}
    base = {t: d for t, d in base.items() if d is not None}
    if base:
        paired_rows(inf, base, len(base)).to_csv(f"{out}/table5_baselines.csv", index=False)

    # Table 6: Fitzpatrick groups at image level, plus both overall rows
    if "fitzpatrick_group" in img:
        rows = []
        overall_img = (img.y_true - img.y_pred).abs().mean()
        for gname, g in img.groupby("fitzpatrick_group"):
            r = regression(g.y_true, g.y_pred)
            lo, hi = bootstrap_ci_mae(g.y_true - g.y_pred)
            rows.append({"group": gname, "n_images": len(g), "n_infants": g.infant_id.nunique(),
                         "MAE": round(r["MAE"], 2), "RMSE": round(r["RMSE"], 2), "R2": round(r["R2"], 2),
                         "CI95_low": round(lo, 2), "CI95_high": round(hi, 2),
                         "delta_vs_image_overall": round(r["MAE"] - overall_img, 2)})
        n = len(img)
        e = img.y_true - img.y_pred
        rows.append({"group": "Overall, image level (n-weighted)", "n_images": n,
                     "MAE": round(e.abs().mean(), 2), "RMSE": round(np.sqrt((e ** 2).mean()), 2)})
        rows.append({"group": "Overall, infant level (headline)", "n_images": len(img), "n_infants": len(inf),
                     "MAE": round(head["MAE"], 2), "RMSE": round(head["RMSE"], 2), "R2": round(head["R2"], 2)})
        t6 = pd.DataFrame(rows)
        t6.to_csv(f"{out}/table6_fitzpatrick.csv", index=False)
        print(t6.to_string(index=False))
        split_infants = (img.groupby("infant_id").fitzpatrick_group.nunique() > 1).sum()
        print(f"infants whose images fall in more than one Fitzpatrick group: {split_infants}")


if __name__ == "__main__":
    main()
