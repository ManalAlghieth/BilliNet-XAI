"""Build the standard manifest (image_path, infant_id, target[, fitzpatrick_group, site]) from a
dataset's own metadata table.

Column names differ between dataset releases, so they are passed explicitly. Example:

  python scripts/make_manifest.py --meta data/NeoJaundice/metadata.csv \
      --image-col image_name --infant-col patient_id --target-col tsb \
      --fitz-col fitzpatrick --image-dir images --out data/neojaundice_manifest.csv

The script checks how many images each infant has and reports it, so the
"three images per infant" assumption of the manuscript can be verified.
"""
import argparse
import pandas as pd

FITZ_GROUPS = {"I": "I-II", "II": "I-II", "III": "III-IV", "IV": "III-IV", "V": "V-VI", "VI": "V-VI",
               "1": "I-II", "2": "I-II", "3": "III-IV", "4": "III-IV", "5": "V-VI", "6": "V-VI"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--meta", required=True)
    ap.add_argument("--image-col", required=True)
    ap.add_argument("--infant-col", required=True)
    ap.add_argument("--target-col", required=True)
    ap.add_argument("--fitz-col")
    ap.add_argument("--site-col")
    ap.add_argument("--image-dir", default="")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    meta = pd.read_csv(a.meta) if a.meta.endswith(".csv") else pd.read_excel(a.meta)
    df = pd.DataFrame({
        "image_path": [f"{a.image_dir}/{x}".lstrip("/") for x in meta[a.image_col].astype(str)],
        "infant_id": meta[a.infant_col].astype(str),
        "target": pd.to_numeric(meta[a.target_col], errors="coerce"),
    })
    if a.fitz_col:
        df["fitzpatrick_group"] = meta[a.fitz_col].astype(str).str.strip().map(FITZ_GROUPS)
    if a.site_col:
        df["site"] = meta[a.site_col].astype(str)
    df = df.dropna(subset=["target"])
    df.to_csv(a.out, index=False)

    per = df.groupby("infant_id").size()
    print(f"images: {len(df)}  infants: {per.size}  images per infant: {per.value_counts().to_dict()}")
    if "fitzpatrick_group" in df:
        mixed = (df.groupby("infant_id").fitzpatrick_group.nunique() > 1).sum()
        print(f"infants with more than one Fitzpatrick group across their images: {mixed}")


if __name__ == "__main__":
    main()
