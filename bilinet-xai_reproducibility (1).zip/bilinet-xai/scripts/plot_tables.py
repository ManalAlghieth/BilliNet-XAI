"""Figs. 8 and 9 drawn from the values in Tables 4 and 5 of the manuscript."""
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','Liberation Serif'],'font.size':10,'mathtext.fontset':'stix'})
# Fig 8 from Table 4
cfg=['Spectral\nOnly','RGB Tokens\n(Cs = 3)','Spatial\nOnly','DSSAT\n(No Gating)','DSSAT\n(No XAI Reg.)','BiliNet-XAI\n(Full)']
mae=[1.42,1.51,1.58,1.12,0.95,0.87]; r2=[0.89,0.88,0.87,0.93,0.95,0.96]
col=['#b0bec5']*3+['#90caf9','#64b5f6','#00b050']
fig,ax=plt.subplots(2,1,figsize=(7.33,4.45))
for a,v,lab,yl,lim in [(ax[0],mae,'(a)','MAE (mg/dL)',(0,1.85)),(ax[1],r2,'(b)','R$^2$',(0.80,1.0))]:
    b=a.bar(range(6),v,color=col,edgecolor='#333',width=0.55)
    for i,x in enumerate(v): a.text(i,x+(lim[1]-lim[0])*0.02,f'{x:.2f}',ha='center',va='bottom',fontsize=9,fontweight='bold')
    a.set_ylim(*lim); a.set_ylabel(yl); a.set_xticks(range(6)); a.set_xticklabels(cfg,fontsize=8.5)
    a.text(-0.07,1.0,lab,transform=a.transAxes,fontweight='bold',va='top',ha='right')
    a.spines[['top','right']].set_visible(False)
fig.tight_layout(); fig.savefig('figures/fig8_ablation.png',dpi=600); plt.close()
# Fig 9 from Table 5
names=['ResNet-50 [34]','DenseNet-121 [35]','EfficientNet-B4 [36]','ViT-B/16 [11]','Swin-T [14]','MobileNet-V3 [37]','InceptionV3 [38]','CMAF-Net [15]','ViT-NeoJaundice [1]','Eliazer ViT-KELM [31]','BiliNet-XAI (Ours)']
mae=[1.82,1.65,1.48,1.35,1.28,1.92,1.55,1.18,1.24,1.31,0.87]; r2=[0.86,0.88,0.90,0.92,0.93,0.84,0.89,0.94,0.93,0.92,0.96]
c1=['#4a90c2']*10+['#2bb44a']; c2=['#e8935a']*10+['#2bb44a']
fig,ax=plt.subplots(1,2,figsize=(7.33,4.87),sharey=True)
y=list(range(len(names)))[::-1]
for a,v,c,lab,xl,lim in [(ax[0],mae,c1,'(a)','MAE (mg/dL), lower is better',(0,2.3)),(ax[1],r2,c2,'(b)','R$^2$, higher is better',(0.80,1.0))]:
    a.barh(y,[x-lim[0] for x in v],left=lim[0],color=c,edgecolor='#333',height=0.6)
    for yy,x in zip(y,v): a.text(x+(lim[1]-lim[0])*0.01,yy,f'{x:.2f}',va='center',fontsize=8.5,fontweight='bold' if yy==0 else 'normal')
    a.set_xlim(*lim); a.set_xlabel(xl); a.spines[['top','right']].set_visible(False)
    a.text(0.0,1.02,lab,transform=a.transAxes,fontweight='bold',va='bottom')
ax[0].set_yticks(y); ax[0].set_yticklabels(names,fontsize=8.5)
fig.tight_layout(); fig.savefig('figures/fig9_comparison.png',dpi=600); plt.close()
