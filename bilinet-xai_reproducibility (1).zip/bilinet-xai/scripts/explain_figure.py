"""Fig. 7: spatial Grad-CAM++ saliency, plus band-level spectral importance for the same images.

  python scripts/explain_figure.py --manifest ... --splits ... --root ... --ckpt runs/full_seed42/final.pt \
      --ids 0008 0141 0335 0346 0386 --out figures
Writes figures/fig7_spatial_gradcampp.png and results/band_importance_test.csv
(mean band-level importance over the whole test split).
"""
import argparse
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import torch  # noqa: E402
from PIL import Image  # noqa: E402
from torch.utils.data import DataLoader  # noqa: E402

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from bilinet.data import ImageTable, MEAN, STD, eval_tf, load_split  # noqa: E402
from bilinet.explain import band_importance, gradcam_pp, upsample  # noqa: E402
from bilinet.model import build_model  # noqa: E402

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif"]})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--splits", required=True)
    ap.add_argument("--root", default=".")
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--ids", nargs="+", required=True, help="substrings of image_path to display")
    ap.add_argument("--out", default="figures")
    a = ap.parse_args()
    model = build_model("full"); model.load_state_dict(torch.load(a.ckpt, map_location="cpu")); model.eval()
    te = load_split(a.manifest, a.splits, "test").reset_index(drop=True)

    imp = []
    for x, _, _ in DataLoader(ImageTable(te, a.root, eval_tf()), 32):
        out = model(x, return_all=True)
        imp.append(band_importance(out["y"], out["spectral_tokens"]).detach())
    imp = torch.cat(imp).mean(0).numpy()
    os.makedirs("results", exist_ok=True)
    pd.DataFrame({"band": np.arange(1, len(imp) + 1), "importance": imp}).to_csv(
        "results/band_importance_test.csv", index=False)

    rows = [te[te.image_path.str.contains(i)].iloc[0] for i in a.ids]
    fig, axes = plt.subplots(len(rows), 2, figsize=(4.0, 1.85 * len(rows)))
    for k, r in enumerate(rows):
        img = Image.open(f"{a.root}/{r.image_path}").convert("RGB")
        x = eval_tf()(img).unsqueeze(0)
        out = model(x, return_all=True)
        cam = upsample(gradcam_pp(out["y"], out["cam_maps"])).detach()[0].numpy()
        disp = (x[0].permute(1, 2, 0).numpy() * STD + MEAN).clip(0, 1)
        axes[k, 0].imshow(disp)
        axes[k, 1].imshow(disp); axes[k, 1].imshow(cam, cmap="inferno", alpha=0.45)
        for ax, lab in zip(axes[k], "ab"):
            ax.set_xticks([]); ax.set_yticks([])
            ax.text(6, 18, f"({chr(97 + 2 * k + (lab == 'b'))})", fontsize=8, fontweight="bold",
                    bbox=dict(fc="white", ec="none", pad=1))
    axes[0, 0].set_title("Input skin region", fontsize=9, fontweight="bold")
    axes[0, 1].set_title("Spatial Grad-CAM++ saliency", fontsize=9, fontweight="bold")
    fig.tight_layout()
    os.makedirs(a.out, exist_ok=True)
    fig.savefig(f"{a.out}/fig7_spatial_gradcampp.png", dpi=600)


if __name__ == "__main__":
    main()
