# BiliNet XAI

Reference implementation and reproducibility package for

> **BiliNet XAI A Multimodal Explainable Deep Learning Framework for Noninvasive Neonatal Bilirubin Estimation**
> (submitted to *Computers, Materials & Continua*).

The repository contains the model (dual-branch spectral-spatial attention transformer with cross-modal gated fusion), the training objective including the Grad-CAM++ saliency-entropy term, the infant-level data splitting procedure, the baseline and ablation protocols, and the statistical analyses behind Tables 3 to 6 and Figures 4 and 7 to 9.

## Repository layout

| Path | Content |
|---|---|
| `bilinet/model.py` | Model, Eqs. (1) to (19); Table 4 variants via `build_model(variant)` |
| `bilinet/losses.py` | Eqs. (20) to (23) and L_xai (entropy of the L1-normalized spatial Grad-CAM++ map) |
| `bilinet/explain.py` | Grad-CAM++ on the spatial branch (Eqs. 24 to 26) and band-level spectral importance |
| `bilinet/metrics.py` | MAE, RMSE, R², Pearson ρ, classification metrics, Wilcoxon, rank-biserial r, Bonferroni, bootstrap intervals |
| `bilinet/data.py` | Manifest-based datasets, severity thresholds, infant-level aggregation |
| `scripts/make_manifest.py` | Converts each dataset's metadata into a standard manifest and checks images per infant |
| `scripts/make_splits.py` | Infant-level 70/15/15 split stratified by severity, seed 42 |
| `scripts/pretrain_fitzpatrick.py` | Spectral-branch pretraining on Fitzpatrick17k |
| `scripts/train.py` | Training (Algorithm 1), per-epoch log for Fig. 4 |
| `scripts/predict.py` | Image-level and infant-level test predictions, latency |
| `scripts/train_baselines.py` | Table 5 baselines under the same protocol |
| `scripts/stats_tables.py` | Tables 3 to 6 from prediction files |
| `scripts/plot_curves.py`, `explain_figure.py`, `plot_tables.py` | Figures 4, 7, 8 and 9 |
| `configs/hyperparameters.yaml` | Table 2 |
| `splits/` | Split index files (infant identifiers per partition) |
| `results/` | Prediction files and recomputed tables |
| `run_all.sh` | End-to-end reproduction |

## Installation

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q tests        # shape, gradient and statistics checks
```

The experiments in the manuscript used PyTorch 2.1 on two NVIDIA A100 (80 GB) GPUs.

## Data

All three datasets are public and must be downloaded from their original sources (they are not redistributed here).

| Dataset | Use | Source |
|---|---|---|
| NeoJaundice (2,235 images, 745 infants) | Regression (TSB), main evaluation | https://springernature.figshare.com/articles/dataset/NeoJaundice_Neonatal_Jaundice_Evaluation_in_Demographic_Images/22302559 |
| Neonatal Jaundice Assessment, forehead and sternum (about 600 images, 300 infants) | Complementary classification validation | https://data.mendeley.com/datasets/yfsz6c36vc/1 |
| Fitzpatrick17k | Spectral-branch pretraining only | https://github.com/mattgroh/fitzpatrick17k |

Place them under `data/` and build the manifests with `scripts/make_manifest.py`, passing the column names of each dataset's metadata file. The script reports the number of images per infant and, if Fitzpatrick labels are given, how many infants have images in more than one Fitzpatrick group.

## Reproducing the paper

```bash
bash run_all.sh
```

or step by step:

1. `make_splits.py` creates `splits/neojaundice_splits.csv` (521/112/112 infants) and `splits/mendeley_splits.csv` (210/45/45 infants). Every infant appears in exactly one partition.
2. `pretrain_fitzpatrick.py` trains the spectral branch for six-class phototype classification (9,847 images, 50 epochs, AdamW 1e-4) and saves `spectral.pt`. The exact image list is written to `splits/fitz17k_subset.csv`.
3. `train.py` trains for 200 epochs with cosine annealing. There is no early stopping; the final-epoch checkpoint is evaluated once on the test split. Use `--seed 0`, `7`, `42` and `123` for the initialization-seed analysis (the split is fixed).
4. `predict.py` writes `*_test_image_predictions.csv` and `*_test_infant_predictions.csv`.
5. `stats_tables.py` recomputes Tables 3 to 6 into `results/tables/`.

### Evaluation units

* **Infant level** (Tables 4 and 5, headline MAE and RMSE): the three predictions of an infant are averaged, then the error is computed. Wilcoxon tests pair infants (n = 112).
* **Image level** (Table 6 group rows and the image-level overall row): errors are computed per image. Bootstrap intervals are over images and do not account for within-infant correlation.

### Statistics

* Table 5: paired Wilcoxon signed-rank tests on per-infant absolute errors, Bonferroni correction for ten comparisons, matched-pairs rank-biserial r, BCa bootstrap 95% intervals (10,000 resamples) on the MAE difference.
* Table 4: the same test, Bonferroni correction for five comparisons.
* Table 6: percentile bootstrap 95% intervals for each group MAE (10,000 resamples, image level).

### Explainability

Grad-CAM++ is applied only to the spatial branch: the 196 spatial tokens are reshaped to 14 × 14 and passed through an identity-initialized 1 × 1 convolution whose output A^k is the target layer and from which z_p is pooled. The same map, L1-normalized, defines L_xai during training. The spectral branch is explained with band-level importance (normalized L1 gradient magnitude per pseudo-spectral token), which has no spatial meaning.

### Parameter count

The manuscript does not state the feed-forward width of the transformer layers; this implementation uses `ffn_dim = 2048`. With that width the trainable parameter counts are 11.27M (full model), 5.30M (spectral only), 5.30M (RGB tokens), 5.61M (spatial only) and 11.01M (no gating). Run `python tests/test_model.py` to print them for any configuration.

## Baselines

General backbones are taken from `timm` with ImageNet weights and a one-output regression head. ViT-NeoJaundice uses a ViT-B/16 backbone. Eliazer ViT-KELM uses fine-tuned ViT-B/16 features followed by kernel extreme learning machine regression. The adapted CMAF-Net must be inserted in `scripts/baselines_custom.py`.

## Citation

If you use this code, please cite the paper above (citation details will be added on publication).

## License

MIT, see `LICENSE`.
