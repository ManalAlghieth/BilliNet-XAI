"""Forward-pass cost of BiliNet-XAI (Section 3.10, Tables 6 and 8), counted analytically from the
model configuration as multiply-accumulate operations (MACs), the convention used for the baseline
GFLOPs values in Table 8. No deep-learning dependencies are needed.

  python scripts/count_complexity.py            # full model, 224 x 224
  python scripts/count_complexity.py --all      # also the Table 5 variants

Counted: patch embedding, spectral 1x1 projection, Q/K/V/output projections, attention products,
feed-forward layers, band gates, auxiliary 1x1 convolution, gated fusion and regression head.
Element-wise operations, softmax, LayerNorm and pooling are not counted (negligible).
"""
import argparse


def macs(img=224, patch=16, c_s=16, d=256, d_f=256, ffn=2048, layers=4,
         branches="both", gating=True, rgb_tokens=False):
    n_p = (img // patch) ** 2
    n_s = 3 if rgb_tokens else c_s

    def layer(n):
        return n * (3 * d * d + d * d + 2 * d * ffn) + 2 * n * n * d

    total = 0
    if branches in ("both", "spectral"):
        total += 0 if rgb_tokens else img * img * 3 * c_s          # learned 1x1 RGB projection (Eq. 1)
        total += layers * (layer(n_s) + n_s * n_s)                  # spectral layers + band gates
    if branches in ("both", "spatial"):
        total += n_p * patch * patch * 3 * d                        # patch embedding (Eq. 10)
        total += layers * layer(n_p)                                # spatial layers
        total += n_p * d * d                                        # auxiliary 1x1 convolution
    if branches == "both":
        total += (2 * (2 * d * d_f) + 2 * d * d_f) if gating else 2 * d * d_f
        head_in = d_f
    else:
        head_in = d
    total += head_in * 128 + 128 * 64 + 64                          # regression head (Eq. 19)
    return total


VARIANTS = {"full": {}, "spectral_only": dict(branches="spectral"),
            "rgb_tokens": dict(branches="spectral", rgb_tokens=True),
            "spatial_only": dict(branches="spatial"), "no_gating": dict(gating=False)}

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--all", action="store_true")
    a = ap.parse_args()
    for v, kw in (VARIANTS.items() if a.all else [("full", {})]):
        print(f"{v:14s} {macs(**kw) / 1e9:.2f} GMACs (reported as GFLOPs in Tables 6 and 8)")
