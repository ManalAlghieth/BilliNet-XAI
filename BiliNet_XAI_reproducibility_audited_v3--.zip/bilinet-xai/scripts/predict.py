"""Predict on a split and write image-level and infant-level prediction files.

Outputs (in --out):
  <tag>_image_predictions.csv   image_path, infant_id, fitzpatrick_group, site, y_true, y_pred
  <tag>_infant_predictions.csv  infant_id, fitzpatrick_group, y_true, y_pred (mean of the infant's images)

  python scripts/predict.py --manifest data/neojaundice_manifest.csv --splits splits/neojaundice_splits.csv \
      --root data/NeoJaundice --ckpt runs/full_seed42/final.pt --variant full --tag bilinet --out results
"""
import argparse
import os
import sys
import time

import pandas as pd
import torch
from torch.utils.data import DataLoader

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from bilinet.data import ImageTable, infant_level, load_split  # noqa: E402
from bilinet.metrics import regression  # noqa: E402
from bilinet.model import build_model, count_params  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--splits", required=True)
    ap.add_argument("--root", default=".")
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--variant", default="full")
    ap.add_argument("--split", default="test")
    ap.add_argument("--tag", required=True)
    ap.add_argument("--out", default="results")
    ap.add_argument("--latency", action="store_true", help="batch-1 latency, 100 warm-up + 500 timed runs")
    a = ap.parse_args()
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    model = build_model(a.variant)
    model.load_state_dict(torch.load(a.ckpt, map_location="cpu"))
    model.to(dev).eval()

    df = load_split(a.manifest, a.splits, a.split)
    preds = []
    with torch.no_grad():
        for x, _, _ in DataLoader(ImageTable(df, a.root), 64, num_workers=8):
            preds.append(model(x.to(dev)).cpu())
    df = df.reset_index(drop=True)
    df["y_true"], df["y_pred"] = df.target, torch.cat(preds).numpy()
    os.makedirs(a.out, exist_ok=True)
    cols = [c for c in ["image_path", "infant_id", "fitzpatrick_group", "site", "y_true", "y_pred"] if c in df]
    df[cols].to_csv(f"{a.out}/{a.tag}_{a.split}_image_predictions.csv", index=False)
    inf = infant_level(df)
    inf.to_csv(f"{a.out}/{a.tag}_{a.split}_infant_predictions.csv", index=False)
    print("image level :", {k: round(v, 4) for k, v in regression(df.y_true, df.y_pred).items()})
    print("infant level:", {k: round(v, 4) for k, v in regression(inf.y_true, inf.y_pred).items()})
    print(f"params: {count_params(model) / 1e6:.2f}M")

    if a.latency:
        x = torch.randn(1, 3, 224, 224, device=dev)
        with torch.no_grad():
            for _ in range(100):
                model(x)
            if dev == "cuda":
                torch.cuda.synchronize()
            t = time.perf_counter()
            for _ in range(500):
                model(x)
            if dev == "cuda":
                torch.cuda.synchronize()
        lat = (time.perf_counter() - t) / 500 * 1000
        print(f"latency batch 1: {lat:.2f} ms on {dev}")
        import pandas as pd  # noqa: E402
        sys.path.insert(0, os.path.dirname(__file__))
        from count_complexity import VARIANTS, macs  # noqa: E402
        gmacs = round(macs(**VARIANTS.get(a.variant, {})) / 1e9, 1) if a.variant in VARIANTS else float("nan")
        pd.DataFrame([{"model": a.tag, "params_M": round(count_params(model) / 1e6, 2), "GFLOPs_MACs": gmacs,
                       "latency_ms_batch1": round(lat, 2), "device": dev}]).to_csv(
            f"{a.out}/efficiency_metrics.csv", index=False)


if __name__ == "__main__":
    main()
