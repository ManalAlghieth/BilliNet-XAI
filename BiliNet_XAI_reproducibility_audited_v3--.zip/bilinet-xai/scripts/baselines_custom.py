"""Hook for baselines whose architecture is taken from their authors' published code.

CMAF-Net (Sun et al., Quant. Imaging Med. Surg. 2024, doi: 10.21037/qims-24-9) was designed for
multi-modal brain tumour segmentation. For Table 6 it was adapted to single-image TSB regression by
replacing the segmentation decoder with global average pooling and a one-output linear head.
Place the adapted network here; build_cmaf_net() must return an nn.Module mapping
(B, 3, 224, 224) images to (B, 1) predictions.
"""


def build_cmaf_net():
    raise NotImplementedError(
        "Insert the adapted CMAF-Net used for Table 6 here (see the docstring above).")
