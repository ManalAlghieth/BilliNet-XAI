"""Train BiliNet XAI or a Table 5 variant (Algorithm 1, Table 2).

No early stopping: the final-epoch checkpoint is saved and evaluated once on the test split.
A per-epoch log (train and validation MAE, R2 and MSE) is written for Figs. 3(a) and 4.

  python scripts/train.py --manifest data/neojaundice_manifest.csv --splits splits/neojaundice_splits.csv \
      --root data/NeoJaundice --variant full --seed 42 --pretrained runs/fitz_pretrain/spectral.pt \
      --out runs/full_seed42
"""
import argparse
import csv
import json
import os
import random
import sys
import time

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from bilinet.data import ImageTable, eval_tf, load_split, train_tf  # noqa: E402
from bilinet.losses import total_loss  # noqa: E402
from bilinet.metrics import regression  # noqa: E402
from bilinet.model import build_model, count_params  # noqa: E402


def seed_all(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)
    torch.backends.cudnn.deterministic, torch.backends.cudnn.benchmark = True, False


def xavier(m):
    for name, mod in m.named_modules():
        if isinstance(mod, nn.Linear):
            nn.init.xavier_uniform_(mod.weight)
            if mod.bias is not None:
                nn.init.zeros_(mod.bias)


@torch.no_grad()
def evaluate(model, loader, dev):
    model.eval()
    ys, ps = [], []
    for x, y, _ in loader:
        ps.append(model(x.to(dev)).cpu()); ys.append(y)
    return regression(torch.cat(ys).numpy(), torch.cat(ps).numpy())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--splits", required=True)
    ap.add_argument("--root", default=".")
    ap.add_argument("--variant", default="full")
    ap.add_argument("--seed", type=int, default=42, help="model-initialization seed (split is fixed)")
    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--wd", type=float, default=1e-4)
    ap.add_argument("--lambdas", type=float, nargs=4, default=[1.0, 0.5, 0.1, 0.05])
    ap.add_argument("--delta", type=float, default=1.5)
    ap.add_argument("--pretrained", help="spectral-branch weights from pretrain_fitzpatrick.py")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    if a.variant == "no_xai_reg":
        a.lambdas[3] = 0.0
    os.makedirs(a.out, exist_ok=True)
    seed_all(a.seed)
    dev = "cuda" if torch.cuda.is_available() else "cpu"

    model = build_model(a.variant)
    xavier(model)
    if a.pretrained and hasattr(model, "pre"):
        own = model.state_dict()
        sd = {k: v for k, v in torch.load(a.pretrained, map_location="cpu").items()
              if k in own and own[k].shape == v.shape}
        model.load_state_dict(sd, strict=False)
        print(f"loaded {len(sd)} pretrained spectral tensors")
    if torch.cuda.device_count() > 1:
        print("note: run with one process per GPU or torchrun for multi-GPU; single-device used here")
    model.to(dev)
    print(f"variant={a.variant} params={count_params(model) / 1e6:.2f}M device={dev}")

    tr = load_split(a.manifest, a.splits, "train")
    va = load_split(a.manifest, a.splits, "val")
    g = torch.Generator().manual_seed(a.seed)
    dl_tr = DataLoader(ImageTable(tr, a.root, train_tf()), a.bs, shuffle=True, num_workers=a.workers,
                       generator=g, drop_last=False)
    dl_tr_eval = DataLoader(ImageTable(tr, a.root, eval_tf()), 64, num_workers=a.workers)
    dl_va = DataLoader(ImageTable(va, a.root, eval_tf()), 64, num_workers=a.workers)

    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, betas=(0.9, 0.999), weight_decay=a.wd)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=a.epochs)
    log = open(f"{a.out}/train_log.csv", "w", newline="")
    w = csv.writer(log)
    w.writerow(["epoch", "loss", "train_MAE", "train_R2", "val_MAE", "val_R2", "seconds", "train_MSE", "val_MSE"])
    for ep in range(1, a.epochs + 1):
        model.train()
        t0, tot, nb = time.time(), 0.0, 0
        for x, y, _ in dl_tr:
            x, y = x.to(dev), y.to(dev)
            out = model(x, return_all=True)
            loss, _ = total_loss(out, y, tuple(a.lambdas), a.delta)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
            tot += loss.item(); nb += 1
        sched.step()
        mt, mv = evaluate(model, dl_tr_eval, dev), evaluate(model, dl_va, dev)
        w.writerow([ep, tot / nb, mt["MAE"], mt["R2"], mv["MAE"], mv["R2"], round(time.time() - t0, 1),
                    mt["RMSE"] ** 2, mv["RMSE"] ** 2])
        log.flush()
        print(f"ep {ep:3d} loss {tot / nb:.4f} val MAE {mv['MAE']:.3f} R2 {mv['R2']:.3f}")
    torch.save(model.state_dict(), f"{a.out}/final.pt")
    json.dump(vars(a), open(f"{a.out}/args.json", "w"), indent=2)


if __name__ == "__main__":
    main()
