"""Predict on the Mendeley test split and write per-image and per-infant classification files.

Outputs (in --out):
  mendeley_bilinet_test_image_predictions.csv
      image_path, infant_id, site, y_true_class, y_pred_class, y_pred_logits (comma-separated)
  mendeley_bilinet_test_infant_predictions.csv
      infant_id, y_true_class, y_pred_class (majority vote over the infant's images)

Also prints per-class metrics and writes the confusion matrix (mendeley_confusion_matrix.csv and
figures/mendeley_confusion_matrix.png, Figure 5b) and the ROC curves (figures/mendeley_roc.png,
Figure 6b). Table 4 is produced from these prediction files by stats_tables.py.

  python scripts/predict_mendeley.py \
      --manifest data/mendeley_manifest.csv \
      --splits splits/mendeley_splits.csv \
      --root data/Mendeley \
      --ckpt runs/mendeley_cls/mendeley_cls_final.pt \
      --label-site mean \
      --out results
"""
import argparse
import os
import sys

import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
from sklearn.metrics import (auc, classification_report, confusion_matrix,
                             roc_auc_score, roc_curve)
from sklearn.preprocessing import label_binarize
from torch.utils.data import DataLoader

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from bilinet.constants import CLASSES  # noqa: E402
from bilinet.data import ImageTable, eval_tf, load_split  # noqa: E402
from bilinet.model import build_model  # noqa: E402

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif"],
                     "font.size": 10, "mathtext.fontset": "stix"})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--splits", required=True)
    ap.add_argument("--root", default=".")
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--label-site", default="mean", choices=["forehead", "sternum", "mean"])
    ap.add_argument("--split", default="test")
    ap.add_argument("--out", default="results")
    a = ap.parse_args()
    dev = "cuda" if torch.cuda.is_available() else "cpu"

    model = build_model("mendeley_cls")
    model.load_state_dict(torch.load(a.ckpt, map_location="cpu"))
    model.to(dev).eval()

    df = load_split(a.manifest, a.splits, a.split, label_site=a.label_site, task="classification")
    all_logits, all_true = [], []
    with torch.no_grad():
        for x, y, _ in DataLoader(ImageTable(df, a.root, eval_tf(), task="classification"), 64, num_workers=8):
            logits = model(x.to(dev))
            all_logits.append(logits.cpu())
            all_true.append(y.long())
    logits = torch.cat(all_logits).numpy()
    y_true = torch.cat(all_true).numpy()
    y_pred = logits.argmax(axis=1)

    df = df.reset_index(drop=True)
    img_out = df[["image_path", "infant_id", "site"]].copy() if "site" in df else df[["image_path", "infant_id"]].copy()
    img_out["y_true_class"] = y_true
    img_out["y_pred_class"] = y_pred
    img_out["y_pred_logits"] = [",".join(f"{v:.4f}" for v in row) for row in logits]

    os.makedirs(a.out, exist_ok=True)
    img_out.to_csv(f"{a.out}/mendeley_bilinet_{a.split}_image_predictions.csv", index=False)

    # Per-infant majority vote
    inf_rows = []
    for iid, grp in img_out.groupby("infant_id"):
        from scipy.stats import mode as _mode
        mv = _mode(grp.y_pred_class.values, keepdims=True).mode[0]
        inf_rows.append({"infant_id": iid, "y_true_class": grp.y_true_class.iloc[0], "y_pred_class": mv})
    inf_df = pd.DataFrame(inf_rows)
    inf_df.to_csv(f"{a.out}/mendeley_bilinet_{a.split}_infant_predictions.csv", index=False)

    # Per-class metrics (Table 4)
    print(classification_report(y_true, y_pred, target_names=CLASSES, digits=3))
    cm = confusion_matrix(y_true, y_pred)
    print("Confusion matrix:\n", cm)
    os.makedirs(f"{a.out}/figures", exist_ok=True)
    pd.DataFrame(cm, index=CLASSES, columns=CLASSES).to_csv(f"{a.out}/mendeley_confusion_matrix.csv")
    figc, axc = plt.subplots(figsize=(4.2, 3.8))
    axc.imshow(cm, cmap="Oranges")
    axc.set_xticks(range(len(CLASSES))); axc.set_xticklabels(CLASSES, rotation=30)
    axc.set_yticks(range(len(CLASSES))); axc.set_yticklabels(CLASSES)
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            axc.text(j, i, int(cm[i, j]), ha="center", va="center", fontweight="bold")
    axc.set_xlabel("Predicted Label"); axc.set_ylabel("True Label")
    axc.set_title(f"Mendeley (b): accuracy {(y_true == y_pred).mean():.3f}")
    figc.tight_layout(); figc.savefig(f"{a.out}/figures/mendeley_confusion_matrix.png", dpi=600); plt.close(figc)
    acc = (y_true == y_pred).mean()
    print(f"Overall accuracy: {acc:.4f}  ({int(acc * len(y_true))}/{len(y_true)})")

    # ROC curves (Figure 6b)
    from scipy.special import softmax  # noqa: E402
    proba = softmax(logits, axis=1)          # same class scores as the Table 4 AUC in stats_tables.py
    yb = label_binarize(y_true, classes=list(range(len(CLASSES))))
    fig, ax = plt.subplots(figsize=(3.5, 3.5))
    colors = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728"]
    for i, (cls, col) in enumerate(zip(CLASSES, colors)):
        fpr, tpr, _ = roc_curve(yb[:, i], proba[:, i])
        auc_val = auc(fpr, tpr)
        ax.plot(fpr, tpr, color=col, lw=1.5, label=f"{cls} (AUC={auc_val:.2f})")
    ax.plot([0, 1], [0, 1], "k--", lw=0.8)
    ax.set_xlabel("False Positive Rate"); ax.set_ylabel("True Positive Rate")
    ax.set_title("Mendeley ROC (b)")
    ax.legend(fontsize=8, loc="lower right")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    os.makedirs(f"{a.out}/figures", exist_ok=True)
    fig.savefig(f"{a.out}/figures/mendeley_roc.png", dpi=600)
    plt.close()
    print(f"ROC figure saved to {a.out}/figures/mendeley_roc.png")


if __name__ == "__main__":
    main()
