"""Train the BiliNet-XAI Mendeley classification variant (Table 4).

The Mendeley model is BiliNet-XAI with the regression head replaced by a
four-class linear classification head (output dimension 4, cross-entropy loss).
Severity class labels are assigned by applying the thresholds in
bilinet/constants.py to the TcB readings.

Label site: set --label-site to 'forehead', 'sternum', or 'mean' to match
the site column used in the Mendeley manifest (confirm with the dataset
authors; default is 'mean').

  python scripts/train_mendeley.py \
      --manifest data/mendeley_manifest.csv \
      --splits splits/mendeley_splits.csv \
      --root data/Mendeley \
      --pretrained runs/fitz_pretrain/spectral.pt \
      --out runs/mendeley_cls
"""
import argparse
import csv
import json
import os
import random
import sys
import time

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from bilinet.constants import CLASSES, severity  # noqa: E402
from bilinet.data import ImageTable, eval_tf, load_split, train_tf  # noqa: E402
from bilinet.metrics import regression  # noqa: E402
from bilinet.model import build_model, count_params  # noqa: E402


def seed_all(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)
    torch.backends.cudnn.deterministic, torch.backends.cudnn.benchmark = True, False


def xavier(m):
    for name, mod in m.named_modules():
        if isinstance(mod, nn.Linear):
            nn.init.xavier_uniform_(mod.weight)
            if mod.bias is not None:
                nn.init.zeros_(mod.bias)


@torch.no_grad()
def evaluate_cls(model, loader, dev):
    model.eval()
    ys, ps, ls = [], [], []
    for x, y, _ in loader:
        logits = model(x.to(dev))
        ps.append(logits.argmax(dim=1).cpu())
        ys.append(y.long())
        ls.append(nn.functional.cross_entropy(logits, y.long().to(dev), reduction="sum").item())
    ys = torch.cat(ys).numpy()
    ps = torch.cat(ps).numpy()
    acc = (ys == ps).mean()
    return acc, sum(ls) / len(ys)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--splits", required=True)
    ap.add_argument("--root", default=".")
    ap.add_argument("--label-site", default="mean",
                    choices=["forehead", "sternum", "mean"],
                    help="TcB site used for severity label; must match manifest column")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--wd", type=float, default=1e-4)
    ap.add_argument("--pretrained", help="spectral-branch weights from pretrain_fitzpatrick.py")
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    seed_all(a.seed)
    dev = "cuda" if torch.cuda.is_available() else "cpu"

    # Build model with classification head (num_classes=4)
    model = build_model("mendeley_cls")  # see bilinet/model.py build_model()
    xavier(model)
    if a.pretrained and hasattr(model, "pre"):
        own = model.state_dict()
        sd = {k: v for k, v in torch.load(a.pretrained, map_location="cpu").items()
              if k in own and own[k].shape == v.shape}
        model.load_state_dict(sd, strict=False)
        print(f"loaded {len(sd)} pretrained spectral tensors")
    model.to(dev)
    print(f"Mendeley classification model, params={count_params(model) / 1e6:.2f}M, device={dev}")

    tr = load_split(a.manifest, a.splits, "train", label_site=a.label_site, task="classification")
    va = load_split(a.manifest, a.splits, "val",   label_site=a.label_site, task="classification")
    g = torch.Generator().manual_seed(a.seed)
    dl_tr = DataLoader(ImageTable(tr, a.root, train_tf(), task="classification"),
                       a.bs, shuffle=True, num_workers=a.workers, generator=g, drop_last=False)
    dl_va = DataLoader(ImageTable(va, a.root, eval_tf(), task="classification"),
                       64, num_workers=a.workers)

    criterion = nn.CrossEntropyLoss()
    opt = torch.optim.AdamW(model.parameters(), lr=a.lr, betas=(0.9, 0.999), weight_decay=a.wd)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=a.epochs)

    log = open(f"{a.out}/train_log_mendeley.csv", "w", newline="")
    w = csv.writer(log)
    w.writerow(["epoch", "loss", "val_loss", "val_acc", "seconds"])
    for ep in range(1, a.epochs + 1):
        model.train()
        t0, tot, nb = time.time(), 0.0, 0
        for x, y, _ in dl_tr:
            x, y = x.to(dev), y.long().to(dev)
            loss = criterion(model(x), y)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
            tot += loss.item(); nb += 1
        sched.step()
        val_acc, val_loss = evaluate_cls(model, dl_va, dev)
        w.writerow([ep, tot / nb, val_loss, round(val_acc, 4), round(time.time() - t0, 1)])
        log.flush()
        print(f"ep {ep:3d} loss {tot / nb:.4f} val acc {val_acc:.4f}")
    torch.save(model.state_dict(), f"{a.out}/mendeley_cls_final.pt")
    json.dump(vars(a), open(f"{a.out}/mendeley_cls_args.json", "w"), indent=2)


if __name__ == "__main__":
    main()
