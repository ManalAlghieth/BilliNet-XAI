"""Recompute Tables 3 to 8 from prediction files written by predict.py and predict_mendeley.py.

Expected files in --results:
  bilinet_test_{image,infant}_predictions.csv        NeoJaundice (Tables 3, 5–8)
  mendeley_bilinet_test_{image,infant}_predictions.csv  Mendeley (Table 4)
  <ablation tag>_test_infant_predictions.csv         Table 5 ablation variants
  <baseline tag>_test_infant_predictions.csv         Table 6 baselines

  python scripts/stats_tables.py --results results
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, roc_curve, auc

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from bilinet.constants import CLASSES, severity  # noqa: E402
from bilinet.metrics import (bca_ci_mean_diff, bonferroni, bootstrap_ci_mae, classification,  # noqa: E402
                             regression, wilcoxon_paired)

ABLATIONS = ["spectral_only", "rgb_tokens", "spatial_only", "no_gating", "no_xai_reg"]
BASELINES = ["resnet50", "densenet121", "efficientnet_b4", "vit_b16", "swin_t", "mobilenet_v3",
             "inception_v3", "cmaf_net", "vit_neojaundice", "eliazer_vit_kelm"]


def load(res, tag, level):
    p = f"{res}/{tag}_test_{level}_predictions.csv"
    return pd.read_csv(p) if os.path.exists(p) else None


def image_cls(res, tag):
    """Image-level four-class accuracy (%) and weighted F1 from thresholded regression output."""
    img = load(res, tag, "image")
    if img is None:
        return {}
    c = classification(severity(img.y_true), severity(img.y_pred))
    return {"Acc_pct": round(100 * c["Accuracy"], 1), "F1_weighted": round(c["F1_weighted"], 2)}


def ordinal_interval_scores(values):
    """Four continuous class scores derived from a scalar TSB estimate.

    Score is negative distance to each severity interval: Normal (-inf,5),
    Mild [5,12), Moderate [12,20), Severe [20,+inf). These are ranking
    scores, not calibrated probabilities. The construction is explicit so
    ROC/AUC are reproducible and not based on hard class labels.
    """
    x = np.asarray(values, dtype=float).reshape(-1, 1)
    lo = np.array([-np.inf, 5.0, 12.0, 20.0])[None, :]
    hi = np.array([5.0, 12.0, 20.0, np.inf])[None, :]
    dist = np.maximum(np.maximum(lo - x, x - hi), 0.0)
    return -dist


def plot_neojaundice_roc(y_true, y_pred, outdir):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    y = severity(y_true)
    scores = ordinal_interval_scores(y_pred)
    rows, aucs = [], []
    fig, ax = plt.subplots(figsize=(3.8, 3.8))
    for c, name in enumerate(CLASSES):
        binary = (y == c).astype(int)
        if binary.min() == binary.max():
            raise ValueError(f"ROC undefined for {name}: test set has only one class outcome")
        fpr, tpr, thresholds = roc_curve(binary, scores[:, c])
        area = float(auc(fpr, tpr)); aucs.append(area)
        ax.plot(fpr, tpr, lw=1.5, label=f"{name} (AUC={area:.3f})")
        rows.extend({"class": name, "fpr": float(x), "tpr": float(z), "threshold": float(t)}
                    for x, z, t in zip(fpr, tpr, thresholds))
    ax.plot([0, 1], [0, 1], "k--", lw=0.8)
    ax.set(xlabel="False Positive Rate", ylabel="True Positive Rate",
           title="NeoJaundice ROC (one-vs-rest; TSB interval-distance scores)")
    ax.legend(fontsize=7, loc="lower right")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout(); fig.savefig(f"{outdir}/neojaundice_roc.png", dpi=600); plt.close(fig)
    pd.DataFrame(rows).to_csv(f"{outdir}/neojaundice_roc_points.csv", index=False)
    return np.asarray(aucs)


def paired_rows(ref, others, m, res=None, ref_tag="bilinet"):
    """One row per compared model plus a first row for the reference model (BiliNet-XAI)."""
    rows = [{"method": ref_tag, **{k: round(v, 3) for k, v in regression(ref.y_true, ref.y_pred).items()},
             **(image_cls(res, ref_tag) if res else {})}]
    a = ref.set_index("infant_id")
    for tag, df in others.items():
        b = df.set_index("infant_id").loc[a.index]
        ea = (a.y_true - a.y_pred).abs().values
        eb = (b.y_true - b.y_pred).abs().values
        p, r = wilcoxon_paired(ea, eb)
        lo, hi = bca_ci_mean_diff(ea, eb)
        rows.append({"method": tag, **{k: round(v, 3) for k, v in regression(b.y_true, b.y_pred).items()},
                     **(image_cls(res, tag) if res else {}),
                     "p_raw": p, "p_bonferroni": bonferroni(p, m), "rank_biserial_r": round(r, 2),
                     "CI95_dMAE_low": round(lo, 2), "CI95_dMAE_high": round(hi, 2)})
    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--allow-count-mismatch", action="store_true",
                    help="diagnostic only: do not enforce the manuscript's documented test counts")
    ap.add_argument("--allow-partial", action="store_true",
                    help="diagnostic only: permit incomplete ablation/baseline prediction sets")
    a = ap.parse_args()
    out = f"{a.results}/tables"
    os.makedirs(out, exist_ok=True)

    # --- NeoJaundice (regression) ---
    img = load(a.results, "bilinet", "image")
    inf = load(a.results, "bilinet", "infant")
    if img is None or inf is None:
        print("NeoJaundice prediction files not found — skipping Tables 3, 5–8.")
    else:
        head = regression(inf.y_true, inf.y_pred)
        print("BiliNet-XAI infant level:", {k: round(v, 3) for k, v in head.items()})
        n_img, n_inf = len(img), img.infant_id.nunique()
        if not a.allow_count_mismatch and (n_img != 336 or n_inf != 112 or len(inf) != 112):
            raise ValueError(f"NeoJaundice test predictions must contain 336 images from 112 infants; "
                             f"found {n_img} images, {n_inf} image-level infants and {len(inf)} infant rows. "
                             "Do not report Table 3/Fig. 5(a) until the split/predictions are reconciled.")
        if set(img.infant_id.astype(str)) != set(inf.infant_id.astype(str)):
            raise ValueError("Image- and infant-level prediction files contain different infant IDs")

        # Table 3: per-class severity classification from regression output
        yc, pc = severity(img.y_true), severity(img.y_pred)
        c = classification(yc, pc)
        aucs = []
        class_scores = ordinal_interval_scores(img.y_pred.values)
        for k in range(4):
            aucs.append(roc_auc_score((yc == k).astype(int), class_scores[:, k]))
        t3 = pd.DataFrame({"class": CLASSES,
                            **{k: np.round(v, 2) for k, v in c["per_class"].items()},
                            "AUC": np.round(aucs, 2)})
        sup = c["per_class"]["support"]; w = sup / sup.sum()
        t3.loc[len(t3)] = {"class": "Weighted Avg", "precision": round(float((c["per_class"]["precision"] * w).sum()), 2),
                           "recall": round(float((c["per_class"]["recall"] * w).sum()), 2),
                           "f1": round(float((c["per_class"]["f1"] * w).sum()), 2),
                           "AUC": round(float((np.asarray(aucs) * w).sum()), 2), "support": int(sup.sum())}
        t3.to_csv(f"{out}/table3_per_class.csv", index=False)
        # Fig. 5(a): NeoJaundice confusion matrix (image level, thresholded regression output)
        from sklearn.metrics import confusion_matrix  # noqa: E402
        cm = confusion_matrix(yc, pc, labels=range(4))
        pd.DataFrame(cm, index=CLASSES, columns=CLASSES).to_csv(f"{out}/neojaundice_confusion_matrix.csv")
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt  # noqa: E401,E402
        fig, ax = plt.subplots(figsize=(4.2, 3.8)); ax.imshow(cm, cmap="Blues")
        ax.set_xticks(range(4)); ax.set_xticklabels(CLASSES, rotation=30); ax.set_yticks(range(4)); ax.set_yticklabels(CLASSES)
        for i in range(4):
            for j in range(4):
                ax.text(j, i, int(cm[i, j]), ha="center", va="center", fontweight="bold")
        ax.set_xlabel("Predicted Label"); ax.set_ylabel("True Label")
        ax.set_title(f"NeoJaundice (a): accuracy {c['Accuracy']:.3f}")
        os.makedirs(f"{a.results}/figures", exist_ok=True)
        fig.tight_layout(); fig.savefig(f"{a.results}/figures/neojaundice_confusion_matrix.png", dpi=600); plt.close(fig)
        roc_auc = plot_neojaundice_roc(img.y_true.values, img.y_pred.values, f"{a.results}/figures")
        print(f"Table 3 accuracy {c['Accuracy']:.3f}; weighted AUC "
              f"{np.average(roc_auc, weights=sup):.3f} (interval-distance scores)")

        # Table 5: require the complete planned set for confirmatory reporting.
        abl = {t: load(a.results, t, "infant") for t in ABLATIONS}
        abl = {t: d for t, d in abl.items() if d is not None}
        if len(abl) != len(ABLATIONS) and not a.allow_partial:
            raise FileNotFoundError(f"Table 5 requires all five ablation prediction files; missing: "
                                    f"{sorted(set(ABLATIONS) - set(abl))}")
        if abl:
            paired_rows(inf, abl, 5, a.results).to_csv(f"{out}/table5_ablation.csv", index=False)
            print(f"Table 5 written ({len(abl)} ablation variants).")

        # Table 6: ten baselines (Bonferroni m = 10)
        base = {t: load(a.results, t, "infant") for t in BASELINES}
        base = {t: d for t, d in base.items() if d is not None}
        if len(base) != len(BASELINES) and not a.allow_partial:
            raise FileNotFoundError(f"Table 6 requires all ten baseline prediction files; missing: "
                                    f"{sorted(set(BASELINES) - set(base))}. CMAF-Net is not implemented in this package.")
        if base:
            paired_rows(inf, base, 10, a.results).to_csv(f"{out}/table6_baselines.csv", index=False)
            print(f"Table 6 written ({len(base)} baselines).")

        # Table 7: Fitzpatrick skin-tone equity at image level
        if "fitzpatrick_group" in img.columns:
            rows = []
            overall_img = (img.y_true - img.y_pred).abs().mean()
            for gname, g in img.groupby("fitzpatrick_group"):
                r = regression(g.y_true, g.y_pred)
                lo, hi = bootstrap_ci_mae(g.y_true - g.y_pred)
                rows.append({"group": gname, "n_images": len(g),
                              "n_infants": g.infant_id.nunique(),
                              "MAE": round(r["MAE"], 2), "RMSE": round(r["RMSE"], 2),
                              "R2": round(r["R2"], 2),
                              "CI95_low": round(lo, 2), "CI95_high": round(hi, 2),
                              "delta_vs_image_overall": round(r["MAE"] - overall_img, 2)})
            e = img.y_true - img.y_pred
            rows.append({"group": "Overall, image level (n-weighted)", "n_images": len(img),
                         "MAE": round(e.abs().mean(), 2),
                         "RMSE": round(np.sqrt((e ** 2).mean()), 2)})
            rows.append({"group": "Overall, infant level (headline)",
                         "n_images": len(img), "n_infants": len(inf),
                         "MAE": round(head["MAE"], 2), "RMSE": round(head["RMSE"], 2),
                         "R2": round(head["R2"], 2)})
            pd.DataFrame(rows).to_csv(f"{out}/table7_fitzpatrick.csv", index=False)
            split_infants = (img.groupby("infant_id").fitzpatrick_group.nunique() > 1).sum()
            print(f"Table 7 written. Infants spanning >1 Fitzpatrick group: {split_infants}")

        # Table 8: efficiency metrics (written by predict.py --latency)
        eff_path = f"{a.results}/efficiency_metrics.csv"
        if os.path.exists(eff_path):
            import shutil
            shutil.copy(eff_path, f"{out}/table8_efficiency.csv")
            print("Table 8 (efficiency) copied to tables/.")
        else:
            print("efficiency_metrics.csv not found — Table 8 skipped (run predict.py --latency).")

    # --- Mendeley (classification, Table 4): image level, one-vs-rest AUC from the softmax of the logits ---
    men_img = load(a.results, "mendeley_bilinet", "image")
    if men_img is None:
        print("Mendeley prediction files not found - skipping Table 4.")
    else:
        n_men_img, n_men_inf = len(men_img), men_img.infant_id.nunique()
        if not a.allow_count_mismatch and (n_men_img != 191 or n_men_inf != 45):
            raise ValueError(f"Mendeley test predictions are documented as 191 images from 45 infants; "
                             f"found {n_men_img} images from {n_men_inf} infants. Verify the public manifest "
                             "and image multiplicity before reporting Table 4/Figs. 5(b)-6(b).")
        from scipy.special import softmax  # noqa: E402
        from sklearn.metrics import precision_recall_fscore_support, roc_auc_score  # noqa: E402
        y, p = men_img.y_true_class.values, men_img.y_pred_class.values
        proba = softmax(np.array([[float(v) for v in str(s_).split(",")] for s_ in men_img.y_pred_logits]), axis=1)
        pr, rc, f1, sup = precision_recall_fscore_support(y, p, labels=range(4), zero_division=0)
        aucs = [roc_auc_score((y == c).astype(int), proba[:, c]) for c in range(4)]
        t4 = [{"class": CLASSES[c], "n": int(sup[c]), "precision": round(pr[c], 2), "recall": round(rc[c], 2),
               "f1": round(f1[c], 2), "auc": round(aucs[c], 2)} for c in range(4)]
        w = sup / sup.sum()
        t4.append({"class": "Weighted Avg", "n": int(sup.sum()), "precision": round(float((pr * w).sum()), 2),
                   "recall": round(float((rc * w).sum()), 2), "f1": round(float((f1 * w).sum()), 2),
                   "auc": round(float((np.array(aucs) * w).sum()), 2)})
        pd.DataFrame(t4).to_csv(f"{out}/table4_mendeley.csv", index=False)
        print(f"Table 4 (Mendeley) written. Image-level accuracy: {(y == p).mean():.3f} ({int((y == p).sum())}/{len(y)})")


if __name__ == "__main__":
    main()
