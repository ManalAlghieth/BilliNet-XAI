"""Re-train the Table 6 baselines for TSB regression under the BiliNet XAI protocol
(same infant-level split, 224 x 224 input, AdamW 1e-4, cosine schedule, 200 epochs, MSE + Huber loss,
final-epoch checkpoint), then write test predictions in the predict.py format.

  python scripts/train_baselines.py --model resnet50 --manifest ... --splits ... --root ... --out results

General backbones come from timm with ImageNet weights. Eliazer ViT-KELM is ViT-B/16 features
followed by a kernel extreme learning machine (closed-form RBF kernel ridge regression).
CMAF-Net must be added in baselines_custom.py from its published code (see README).
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from bilinet.data import ImageTable, eval_tf, infant_level, load_split, train_tf  # noqa: E402
from bilinet.metrics import regression  # noqa: E402

TIMM = {"resnet50": "resnet50", "densenet121": "densenet121", "efficientnet_b4": "efficientnet_b4",
        "vit_b16": "vit_base_patch16_224", "swin_t": "swin_tiny_patch4_window7_224",
        "mobilenet_v3": "mobilenetv3_large_100", "inception_v3": "inception_v3",
        "vit_neojaundice": "vit_base_patch16_224"}


def build(name):
    import timm
    if name == "cmaf_net":
        from baselines_custom import build_cmaf_net
        return build_cmaf_net()
    return timm.create_model(TIMM[name], pretrained=True, num_classes=1)


def run_loader(model, loader, dev):
    model.eval(); out = []
    with torch.no_grad():
        for x, _, _ in loader:
            out.append(model(x.to(dev)).squeeze(-1).cpu())
    return torch.cat(out).numpy()


def train_regressor(model, dl, epochs, dev):
    opt = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    for ep in range(epochs):
        model.train()
        for x, y, _ in dl:
            p = model(x.to(dev)).squeeze(-1)
            loss = F.mse_loss(p, y.to(dev)) + 0.5 * F.huber_loss(p, y.to(dev), delta=1.5)
            opt.zero_grad(); loss.backward(); opt.step()
        sched.step()
        print(f"epoch {ep + 1}/{epochs}", flush=True)


def kelm_fit_predict(ftr, ytr, fte, gamma=None, c=1.0):
    """Kernel ELM regression: beta = (I/C + K)^-1 y with an RBF kernel."""
    gamma = gamma or 1.0 / ftr.shape[1]
    def k(a, b):
        d = (a ** 2).sum(1)[:, None] + (b ** 2).sum(1)[None] - 2 * a @ b.T
        return np.exp(-gamma * d)
    beta = np.linalg.solve(np.eye(len(ftr)) / c + k(ftr, ftr), ytr)
    return k(fte, ftr) @ beta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, choices=list(TIMM) + ["cmaf_net", "eliazer_vit_kelm"])
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--splits", required=True)
    ap.add_argument("--root", default=".")
    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="results")
    ap.add_argument("--ckpt-dir", default="runs/baselines", help="where the trained network is saved (used by zero_shot_mendeley.py)")
    a = ap.parse_args()
    import random
    random.seed(a.seed); torch.manual_seed(a.seed); np.random.seed(a.seed); torch.cuda.manual_seed_all(a.seed)
    torch.backends.cudnn.deterministic, torch.backends.cudnn.benchmark = True, False
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    tr, te = load_split(a.manifest, a.splits, "train"), load_split(a.manifest, a.splits, "test")
    g = torch.Generator().manual_seed(a.seed)
    dl_tr = DataLoader(ImageTable(tr, a.root, train_tf()), 32, shuffle=True, num_workers=8, generator=g)
    dl_te = DataLoader(ImageTable(te, a.root, eval_tf()), 64, num_workers=8)

    if a.model == "eliazer_vit_kelm":
        vit = build("vit_b16").to(dev)
        train_regressor(vit, dl_tr, a.epochs, dev)            # fine-tune the ViT feature extractor
        vit.reset_classifier(0)
        feat = lambda df: run_loader(vit, DataLoader(ImageTable(df, a.root, eval_tf()), 64), dev)
        ftr = feat(tr)
        pred = kelm_fit_predict(ftr, tr.target.values, feat(te))
        os.makedirs(a.ckpt_dir, exist_ok=True)
        torch.save({"vit": vit.state_dict(), "train_features": ftr, "train_targets": tr.target.values},
                   f"{a.ckpt_dir}/{a.model}.pt")
    else:
        model = build(a.model).to(dev)
        train_regressor(model, dl_tr, a.epochs, dev)
        pred = run_loader(model, dl_te, dev)
        os.makedirs(a.ckpt_dir, exist_ok=True)
        torch.save(model.state_dict(), f"{a.ckpt_dir}/{a.model}.pt")

    te = te.reset_index(drop=True)
    te["y_true"], te["y_pred"] = te.target, pred
    os.makedirs(a.out, exist_ok=True)
    cols = [c for c in ["image_path", "infant_id", "fitzpatrick_group", "y_true", "y_pred"] if c in te]
    te[cols].to_csv(f"{a.out}/{a.model}_test_image_predictions.csv", index=False)
    inf = infant_level(te)
    inf.to_csv(f"{a.out}/{a.model}_test_infant_predictions.csv", index=False)
    print(a.model, {k: round(v, 3) for k, v in regression(inf.y_true, inf.y_pred).items()})


if __name__ == "__main__":
    main()
