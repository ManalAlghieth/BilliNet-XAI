"""Aggregate per-infant predictions across four initialization seeds (0, 7, 42, 123).

For each seed the infant-level prediction file must already exist at:
  runs/full_seed{seed}/bilinet_test_infant_predictions.csv

The script reports per-seed metrics and a mean-ensemble prediction, then reports MAE, RMSE and R² with their standard deviations
across seeds.  These values are reported in Section 4.1.1 of the manuscript:
  MAE  0.89 ± 0.03 mg/dL
  R²   0.96 ± 0.004

Usage:
  python scripts/aggregate_seeds.py
  python scripts/aggregate_seeds.py --seeds 0 7 42 123 --run-root runs --out results
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from bilinet.metrics import regression  # noqa: E402


def load_seed(run_root, seed):
    p = os.path.join(run_root, f"full_seed{seed}", "bilinet_test_infant_predictions.csv")
    if not os.path.exists(p):
        raise FileNotFoundError(f"Seed {seed} predictions not found at {p}")
    return pd.read_csv(p).set_index("infant_id")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 7, 42, 123])
    ap.add_argument("--run-root", default="runs")
    ap.add_argument("--out", default="results")
    a = ap.parse_args()

    dfs = []
    for s in a.seeds:
        df = load_seed(a.run_root, s)
        dfs.append(df)

    # Align indices
    common = dfs[0].index
    for d in dfs[1:]:
        common = common.intersection(d.index)
    dfs = [d.loc[common] for d in dfs]

    y_true = dfs[0].loc[common, "y_true"].values
    preds  = np.stack([d.loc[common, "y_pred"].values for d in dfs], axis=1)

    # Per-seed metrics
    per_seed = []
    for i, s in enumerate(a.seeds):
        m = regression(y_true, preds[:, i])
        per_seed.append({"seed": s, **{k: round(v, 4) for k, v in m.items()}})
    df_per = pd.DataFrame(per_seed)

    print("Per-seed metrics:")
    print(df_per.to_string(index=False))
    print()

    # Mean-ensemble (average across seeds)
    y_ens = preds.mean(axis=1)
    ens   = regression(y_true, y_ens)
    print("Mean-ensemble:", {k: round(v, 4) for k, v in ens.items()})
    print()

    # Summary (mean ± std across seeds, as reported in manuscript)
    summary_rows = []
    for metric in ["MAE", "RMSE", "R2", "rho"]:
        vals = df_per[metric].values
        summary_rows.append({"metric": metric,
                              "mean":  round(vals.mean(), 4),
                              "std":   round(vals.std(ddof=1), 4)})
    df_summary = pd.DataFrame(summary_rows)
    print("Seed-mean ± std:")
    print(df_summary.to_string(index=False))

    # Write outputs
    os.makedirs(a.out, exist_ok=True)
    df_per.to_csv(f"{a.out}/seed_analysis_per_seed.csv", index=False)
    df_summary.to_csv(f"{a.out}/seed_analysis_summary.csv", index=False)

    # Ensemble infant-level predictions (seed-42 is the primary checkpoint)
    ens_df = pd.DataFrame({"infant_id": common, "y_true": y_true, "y_pred": y_ens})
    ens_df.to_csv(f"{a.out}/bilinet_ensemble_infant_predictions.csv", index=False)
    print(f"\nOutputs written to {a.out}/")


if __name__ == "__main__":
    main()
