"""Figs. 8 and 9 drawn from Tables 5 and 6 (CSV files in results/tables/).

Previously this script embedded numeric values as Python literals.
It now reads from the CSV files produced by stats_tables.py so that
any re-run of the experiments automatically updates the figures.

Usage:
  python scripts/plot_tables.py --results results
"""
import argparse
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Liberation Serif"],
    "font.size": 10,
    "mathtext.fontset": "stix",
})

ABLATION_LABELS = {
    "spectral_only": "Spectral\nOnly",
    "rgb_tokens": "RGB Tokens\n(Cs = 3)",
    "spatial_only": "Spatial\nOnly",
    "no_gating": "DSSAT\n(No Gating)",
    "no_xai_reg": "DSSAT\n(No XAI Reg.)",
}

BASELINE_DISPLAY = {
    "resnet50":          "ResNet-50 [34]",
    "densenet121":       "DenseNet-121 [35]",
    "efficientnet_b4":   "EfficientNet-B4 [36]",
    "vit_b16":           "ViT-B/16 [11]",
    "swin_t":            "Swin-T [14]",
    "mobilenet_v3":      "MobileNet-V3 [37]",
    "inception_v3":      "InceptionV3 [38]",
    "cmaf_net":          "CMAF-Net [15]",
    "vit_neojaundice":   "ViT-NeoJaundice [1]",
    "eliazer_vit_kelm":  "Eliazer ViT-KELM [31]",
}


def fig8_ablation(tables_dir, out_dir):
    """Fig. 8 — ablation study bar chart (Table 5 CSV)."""
    path = os.path.join(tables_dir, "table5_ablation.csv")
    if not os.path.exists(path):
        print(f"[skip] {path} not found — Fig. 8 not generated.")
        return
    df = pd.read_csv(path)

    # Build ordered list: ablations in canonical order, then BiliNet-XAI (Full)
    ordered = list(ABLATION_LABELS.keys())
    cfg, mae, r2 = [], [], []
    for tag in ordered:
        row = df[df.method == tag]
        if row.empty:
            continue
        cfg.append(ABLATION_LABELS[tag])
        mae.append(float(row.MAE.iloc[0]))
        r2.append(float(row.R2.iloc[0]))

    # Append full-model row (read from efficiency or headline; use BiliNet row in table5 if present)
    full_row = df[df.method == "bilinet"]
    if not full_row.empty:
        cfg.append("BiliNet-XAI\n(Full)")
        mae.append(float(full_row.MAE.iloc[0]))
        r2.append(float(full_row.R2.iloc[0]))
    else:
        cfg.append("BiliNet-XAI\n(Full)")
        mae.append(float("nan"))
        r2.append(float("nan"))

    n = len(cfg)
    col = ["#b0bec5"] * (n - 1) + ["#00b050"]
    fig, axes = plt.subplots(2, 1, figsize=(7.33, 4.45))
    for ax, vals, label, ylabel, ylim in [
        (axes[0], mae, "(a)", "MAE (mg/dL)", (0, max(v for v in mae if not np.isnan(v)) * 1.25)),
        (axes[1], r2,  "(b)", "R$^2$",       (min(v for v in r2  if not np.isnan(v)) * 0.98, 1.0)),
    ]:
        bars = ax.bar(range(n), vals, color=col, edgecolor="#333", width=0.55)
        for i, v in enumerate(vals):
            if not np.isnan(v):
                ax.text(i, v + (ylim[1] - ylim[0]) * 0.02, f"{v:.2f}",
                        ha="center", va="bottom", fontsize=9, fontweight="bold")
        ax.set_ylim(*ylim)
        ax.set_ylabel(ylabel)
        ax.set_xticks(range(n))
        ax.set_xticklabels(cfg, fontsize=8.5)
        ax.text(-0.07, 1.0, label, transform=ax.transAxes, fontweight="bold", va="top", ha="right")
        ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    os.makedirs(out_dir, exist_ok=True)
    fig.savefig(os.path.join(out_dir, "fig8_ablation.png"), dpi=600)
    plt.close()
    print(f"Fig. 8 saved to {out_dir}/fig8_ablation.png")


def fig9_comparison(tables_dir, out_dir):
    """Fig. 9 — baseline comparison horizontal bar chart (Table 6 CSV)."""
    path = os.path.join(tables_dir, "table6_baselines.csv")
    if not os.path.exists(path):
        print(f"[skip] {path} not found — Fig. 9 not generated.")
        return
    df = pd.read_csv(path)

    names, mae, r2 = [], [], []
    for tag, display in BASELINE_DISPLAY.items():
        row = df[df.method == tag]
        if row.empty:
            continue
        names.append(display)
        mae.append(float(row.MAE.iloc[0]))
        r2.append(float(row.R2.iloc[0]))

    # Append BiliNet-XAI (Ours) from bilinet row or separate headline file
    bilinet_row = df[df.method == "bilinet"]
    if not bilinet_row.empty:
        names.append("BiliNet-XAI (Ours)")
        mae.append(float(bilinet_row.MAE.iloc[0]))
        r2.append(float(bilinet_row.R2.iloc[0]))

    n = len(names)
    c1 = ["#4a90c2"] * (n - 1) + ["#2bb44a"]
    c2 = ["#e8935a"] * (n - 1) + ["#2bb44a"]
    y = list(range(n))[::-1]

    mae_min = min(mae)
    r2_min  = min(r2)
    lim_mae = (max(0, mae_min * 0.9), max(mae) * 1.15)
    lim_r2  = (max(0.80, r2_min * 0.995), 1.0)

    fig, axes = plt.subplots(1, 2, figsize=(7.33, 4.87), sharey=True)
    for ax, vals, colors, label, xlabel, lim in [
        (axes[0], mae, c1, "(a)", "MAE (mg/dL), lower is better", lim_mae),
        (axes[1], r2,  c2, "(b)", "R$^2$, higher is better",       lim_r2),
    ]:
        ax.barh(y, [v - lim[0] for v in vals], left=lim[0], color=colors, edgecolor="#333", height=0.6)
        for yy, v in zip(y, vals):
            fw = "bold" if yy == 0 else "normal"
            ax.text(v + (lim[1] - lim[0]) * 0.01, yy, f"{v:.2f}",
                    va="center", fontsize=8.5, fontweight=fw)
        ax.set_xlim(*lim)
        ax.set_xlabel(xlabel)
        ax.spines[["top", "right"]].set_visible(False)
        ax.text(0.0, 1.02, label, transform=ax.transAxes, fontweight="bold", va="bottom")
    axes[0].set_yticks(y)
    axes[0].set_yticklabels(names, fontsize=8.5)
    fig.tight_layout()
    os.makedirs(out_dir, exist_ok=True)
    fig.savefig(os.path.join(out_dir, "fig9_comparison.png"), dpi=600)
    plt.close()
    print(f"Fig. 9 saved to {out_dir}/fig9_comparison.png")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--figures-out", default="figures")
    a = ap.parse_args()
    tables_dir = os.path.join(a.results, "tables")
    fig8_ablation(tables_dir, a.figures_out)
    fig9_comparison(tables_dir, a.figures_out)


if __name__ == "__main__":
    main()
