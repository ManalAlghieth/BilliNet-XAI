"""Infant-level stratified k-fold cross-validation of BiliNet-XAI and the Table 6 baselines.

This protocol corresponds to the cross-validation listed as future work in Section 5 of the
manuscript; it was not used for any result reported there.

Each infant is assigned to exactly one test fold. Folds are stratified jointly by the severity class
of the infant's mean TSB and by Fitzpatrick group. Within the remaining k-1 folds, 15% of all infants
(severity-stratified, seed 42) form the validation partition used for training-curve monitoring; the
rest are used for training. For every fold the full model (and, optionally, the baselines) is trained
with the unchanged protocol of Table 2 and evaluated once on the held-out fold.

  python scripts/kfold_cv.py --manifest data/neojaundice_manifest.csv --root data/NeoJaundice \
      --pretrained runs/fitz_pretrain/spectral.pt --folds 5 --out results/kfold \
      [--baselines resnet50 swin_t ...] [--dry-run] [--aggregate-only]

Outputs in --out: fold<k>/ prediction files, kfold_per_fold.csv (MAE, RMSE, R2, rho per model and fold),
kfold_summary.csv (mean and SD across folds) and kfold_paired_tests.csv (per-fold and pooled paired
Wilcoxon tests against BiliNet-XAI with Bonferroni correction).
"""
import argparse
import os
import subprocess
import sys

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold, train_test_split

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
from bilinet.constants import severity  # noqa: E402
from bilinet.metrics import bonferroni, regression, wilcoxon_paired  # noqa: E402


def build_folds(manifest_path, n_folds=5, seed=42, val=0.15):
    df = pd.read_csv(manifest_path)
    agg = {"target": "mean"}
    if "fitzpatrick_group" in df:
        agg["fitzpatrick_group"] = "first"
    inf = df.groupby("infant_id", as_index=False).agg(agg)
    inf["severity"] = severity(inf.target)
    fitz = inf.fitzpatrick_group.astype(str) if "fitzpatrick_group" in inf else "all"
    inf["stratum"] = inf.severity.astype(str) + "_" + fitz
    skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=seed)
    n_val = round(len(inf) * val)
    folds = []
    for tr_idx, te_idx in skf.split(inf.infant_id, inf.stratum):
        rest, te = inf.iloc[tr_idx], inf.iloc[te_idx]
        tr, va = train_test_split(rest, test_size=n_val, stratify=rest.severity, random_state=seed)
        folds.append(pd.concat([tr.assign(split="train"), va.assign(split="val"), te.assign(split="test")])
                     [["infant_id", "split", "severity"]])
    return folds


def run(cmd):
    print("+", " ".join(cmd), flush=True)
    subprocess.run(cmd, check=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--root", default="data/NeoJaundice")
    ap.add_argument("--pretrained", default="runs/fitz_pretrain/spectral.pt")
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--baselines", nargs="*", default=[])
    ap.add_argument("--out", default="results/kfold")
    ap.add_argument("--runs", default="runs/kfold")
    ap.add_argument("--dry-run", action="store_true", help="write the fold split files only")
    ap.add_argument("--aggregate-only", action="store_true", help="skip training; aggregate existing predictions")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    py = sys.executable
    folds = build_folds(a.manifest, a.folds, a.seed)
    for k, f in enumerate(folds, 1):
        path = f"{a.out}/fold{k}_splits.csv"
        f.to_csv(path, index=False)
        print(f"fold {k}: " + ", ".join(f"{s} {n}" for s, n in f.split.value_counts().items()))
    if a.dry_run:
        return

    models = ["bilinet"] + list(a.baselines)
    if not a.aggregate_only:
        for k in range(1, a.folds + 1):
            sp, od, rd = f"{a.out}/fold{k}_splits.csv", f"{a.out}/fold{k}", f"{a.runs}/fold{k}"
            run([py, f"{HERE}/train.py", "--manifest", a.manifest, "--splits", sp, "--root", a.root,
                 "--variant", "full", "--seed", str(a.seed), "--pretrained", a.pretrained, "--out", f"{rd}/full"])
            run([py, f"{HERE}/predict.py", "--manifest", a.manifest, "--splits", sp, "--root", a.root,
                 "--ckpt", f"{rd}/full/final.pt", "--tag", "bilinet", "--out", od])
            for m in a.baselines:
                run([py, f"{HERE}/train_baselines.py", "--model", m, "--manifest", a.manifest, "--splits", sp,
                     "--root", a.root, "--seed", str(a.seed), "--out", od, "--ckpt-dir", f"{rd}/baselines"])

    per_fold, pooled = [], {m: [] for m in models}
    tests = []
    for k in range(1, a.folds + 1):
        preds = {}
        for m in models:
            p = f"{a.out}/fold{k}/{m}_test_infant_predictions.csv"
            if os.path.exists(p):
                preds[m] = pd.read_csv(p).set_index("infant_id")
                pooled[m].append(preds[m])
                per_fold.append({"fold": k, "model": m, **regression(preds[m].y_true, preds[m].y_pred)})
        if "bilinet" in preds:
            ref = preds["bilinet"]
            others = [m for m in preds if m != "bilinet"]
            for m in others:
                b = preds[m].loc[ref.index]
                pv, r = wilcoxon_paired((ref.y_true - ref.y_pred).abs(), (b.y_true - b.y_pred).abs())
                tests.append({"fold": k, "model": m, "p_raw": pv, "p_bonferroni": bonferroni(pv, len(others)),
                              "rank_biserial_r": r})
    pf = pd.DataFrame(per_fold)
    pf.to_csv(f"{a.out}/kfold_per_fold.csv", index=False)
    if not pf.empty:
        summ = pf.groupby("model")[["MAE", "RMSE", "R2", "rho"]].agg(["mean", lambda x: np.std(x, ddof=1)])
        summ.columns = [f"{c}_{'mean' if s == 'mean' else 'sd'}" for c, s in summ.columns]
        summ.to_csv(f"{a.out}/kfold_summary.csv")
        print(summ.round(3).to_string())
    if pooled.get("bilinet"):
        ref = pd.concat(pooled["bilinet"])
        others = [m for m in models if m != "bilinet" and pooled[m]]
        for m in others:
            b = pd.concat(pooled[m]).loc[ref.index]
            pv, r = wilcoxon_paired((ref.y_true - ref.y_pred).abs(), (b.y_true - b.y_pred).abs())
            tests.append({"fold": "pooled", "model": m, "p_raw": pv,
                          "p_bonferroni": bonferroni(pv, len(others)), "rank_biserial_r": r})
    pd.DataFrame(tests).to_csv(f"{a.out}/kfold_paired_tests.csv", index=False)


if __name__ == "__main__":
    main()
