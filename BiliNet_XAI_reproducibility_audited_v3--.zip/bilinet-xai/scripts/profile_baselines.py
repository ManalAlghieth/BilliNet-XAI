"""Profile baseline parameter counts and forward MAC/FLOP estimates at 224x224.

Requires optional fvcore: pip install fvcore==0.1.5.post20221221
Example: python scripts/profile_baselines.py --out results/tables/baseline_complexity.csv

The report records the profiler convention and unsupported operators. Compare only
numbers obtained with the same profiler/version/input shape; MAC and FLOP conventions
are not interchangeable. This script does not measure latency.
"""
import argparse
import os

import pandas as pd
import torch

MODELS = {
    "resnet50": "resnet50",
    "densenet121": "densenet121",
    "efficientnet_b4": "efficientnet_b4",
    "vit_b16": "vit_base_patch16_224",
    "swin_t": "swin_tiny_patch4_window7_224",
    "mobilenet_v3": "mobilenetv3_large_100",
    "inception_v3": "inception_v3",
    "vit_neojaundice": "vit_base_patch16_224",
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="results/tables/baseline_complexity.csv")
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    a = ap.parse_args()
    try:
        import timm
        from fvcore.nn import FlopCountAnalysis
    except ImportError as exc:
        raise SystemExit("Install optional dependencies with: pip install timm fvcore") from exc

    rows = []
    for name, arch in MODELS.items():
        model = timm.create_model(arch, pretrained=False, num_classes=1).to(a.device).eval()
        x = torch.zeros(1, 3, 224, 224, device=a.device)
        with torch.no_grad():
            analysis = FlopCountAnalysis(model, x)
            flops = analysis.total()
        rows.append({
            "model": name,
            "architecture": arch,
            "input_shape": "1x3x224x224",
            "params_M": sum(p.numel() for p in model.parameters()) / 1e6,
            "fvcore_FLOPs_G": flops / 1e9,
            "unsupported_ops": str(analysis.unsupported_ops()),
            "device": a.device,
            "profiler": "fvcore FlopCountAnalysis",
        })
        print(rows[-1])
        del model
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    pd.DataFrame(rows).to_csv(a.out, index=False)
    print(f"Saved {a.out}; CMAF-Net and ViT-KELM head costs require separate implementation/profiling.")


if __name__ == "__main__":
    main()
