"""Zero-shot cross-dataset evaluation: NeoJaundice-trained models applied to Mendeley without retraining.

This protocol corresponds to the zero-shot evaluation listed as future work in Section 5 of the
manuscript; it was not used for any result reported there.

No weights are updated. Mendeley test images receive the preprocessing of Supplementary Section S3.1.
  * Classification: the regression output (mg/dL) is mapped to the four severity classes with the
    thresholds of bilinet/constants.py and compared with the Mendeley labels (class of the per-infant
    mean TcB, as for Table 4). Image-level accuracy, per-class precision/recall/F1 and the confusion
    matrix are reported.
  * Regression (optional): if the Mendeley manifest has a `tsb` column (make_manifest.py --tsb-col),
    MAE, RMSE, R2 and rho against TSB are reported at image and infant level, and per-infant absolute
    errors of each baseline are compared with BiliNet-XAI by paired Wilcoxon tests (Bonferroni).

  python scripts/zero_shot_mendeley.py --ckpt runs/full_seed42/final.pt \
      --manifest data/mendeley_manifest.csv --splits splits/mendeley_splits.csv --root data/Mendeley \
      [--baseline-ckpt-dir runs/baselines --baselines resnet50 swin_t ...] --out results/zero_shot
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, ".."))
sys.path.insert(0, HERE)
from bilinet.constants import CLASSES, infant_level, severity  # noqa: E402
from bilinet.data import ImageTable, eval_tf, load_split  # noqa: E402
from bilinet.metrics import bonferroni, classification, regression, wilcoxon_paired  # noqa: E402
from bilinet.model import build_model  # noqa: E402


@torch.no_grad()
def predict(model, df, root, dev):
    model.eval(); out = []
    for x, _, _ in DataLoader(ImageTable(df, root, eval_tf()), 64, num_workers=8):
        out.append(model(x.to(dev)).reshape(-1).cpu())
    return torch.cat(out).numpy()


def load_baseline(name, ckpt_dir, dev):
    from train_baselines import build, kelm_fit_predict, run_loader  # noqa: E402
    if name == "eliazer_vit_kelm":
        st = torch.load(f"{ckpt_dir}/{name}.pt", map_location="cpu")
        vit = build("vit_b16"); vit.reset_classifier(0); vit.load_state_dict(st["vit"]); vit.to(dev)

        def f(df, root):
            fte = run_loader(vit, DataLoader(ImageTable(df, root, eval_tf()), 64), dev)
            return kelm_fit_predict(st["train_features"], st["train_targets"], fte)
        return f
    m = build(name); m.load_state_dict(torch.load(f"{ckpt_dir}/{name}.pt", map_location="cpu")); m.to(dev)
    return lambda df, root: predict(m, df, root, dev)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True, help="NeoJaundice-trained BiliNet-XAI checkpoint")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--splits", required=True)
    ap.add_argument("--root", default="data/Mendeley")
    ap.add_argument("--label-site", default="mean", choices=["forehead", "sternum", "mean"])
    ap.add_argument("--split", default="test")
    ap.add_argument("--baselines", nargs="*", default=[])
    ap.add_argument("--baseline-ckpt-dir", default="runs/baselines")
    ap.add_argument("--out", default="results/zero_shot")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    df = load_split(a.manifest, a.splits, a.split, label_site=a.label_site, task="classification").reset_index(drop=True)

    bili = build_model("full"); bili.load_state_dict(torch.load(a.ckpt, map_location="cpu")); bili.to(dev)
    predictors = {"bilinet": lambda d, r: predict(bili, d, r, dev)}
    for b in a.baselines:
        predictors[b] = load_baseline(b, a.baseline_ckpt_dir, dev)

    cls_rows, reg_rows, inf_err = [], [], {}
    for name, fn in predictors.items():
        yhat = fn(df, a.root)
        pred = df[["image_path", "infant_id"]].copy()
        pred["y_pred_mg_dl"], pred["y_true_class"], pred["y_pred_class"] = yhat, df.label.values, severity(yhat)
        if "tsb" in df:
            pred["tsb"] = df.tsb.values
        pred.to_csv(f"{a.out}/{name}_zero_shot_image_predictions.csv", index=False)
        c = classification(pred.y_true_class, pred.y_pred_class)
        row = {"model": name, "n_images": len(pred), "accuracy": c["Accuracy"], "F1_weighted": c["F1_weighted"]}
        for i, cl in enumerate(CLASSES):
            row.update({f"{cl}_precision": c["per_class"]["precision"][i], f"{cl}_recall": c["per_class"]["recall"][i],
                        f"{cl}_f1": c["per_class"]["f1"][i], f"{cl}_n": int(c["per_class"]["support"][i])})
        cls_rows.append(row)
        from sklearn.metrics import confusion_matrix  # noqa: E402
        pd.DataFrame(confusion_matrix(pred.y_true_class, pred.y_pred_class, labels=range(4)),
                     index=CLASSES, columns=CLASSES).to_csv(f"{a.out}/{name}_zero_shot_confusion_matrix.csv")
        if "tsb" in pred:
            img = pred.rename(columns={"tsb": "y_true", "y_pred_mg_dl": "y_pred"})
            inf = infant_level(img[["infant_id", "y_true", "y_pred"]])
            reg_rows.append({"model": name, **{f"image_{k}": v for k, v in regression(img.y_true, img.y_pred).items()},
                             **{f"infant_{k}": v for k, v in regression(inf.y_true, inf.y_pred).items()}})
            inf_err[name] = inf.set_index("infant_id").eval("abs(y_true - y_pred)")
    pd.DataFrame(cls_rows).to_csv(f"{a.out}/zero_shot_classification.csv", index=False)
    print(pd.DataFrame(cls_rows)[["model", "n_images", "accuracy", "F1_weighted"]].round(3).to_string(index=False))
    if reg_rows:
        pd.DataFrame(reg_rows).to_csv(f"{a.out}/zero_shot_regression_tsb.csv", index=False)
        others = [m for m in inf_err if m != "bilinet"]
        tests = []
        for m in others:
            e_ref, e_b = inf_err["bilinet"], inf_err[m].loc[inf_err["bilinet"].index]
            pv, r = wilcoxon_paired(e_ref.values, e_b.values)
            tests.append({"model": m, "p_raw": pv, "p_bonferroni": bonferroni(pv, len(others)), "rank_biserial_r": r})
        pd.DataFrame(tests).to_csv(f"{a.out}/zero_shot_paired_tests.csv", index=False)


if __name__ == "__main__":
    main()
