"""Datasets, transforms, severity classes and infant-level aggregation.

All scripts work from a manifest CSV with one row per image and the columns
    image_path, infant_id, target            (required)
    fitzpatrick_group, site                   (optional)
`target` is TSB in mg/dL for NeoJaundice and the TcB reading (one row per image and site) for Mendeley.
"""
import pandas as pd
import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms as T

from .constants import CLASSES, THRESHOLDS, infant_level, severity, severity_label  # noqa: F401

MEAN, STD = (0.485, 0.456, 0.406), (0.229, 0.224, 0.225)


def train_tf(size=224):
    # Geometric augmentation only: colour jitter would alter the chromatic signal being estimated.
    return T.Compose([T.Resize((size, size)), T.RandomHorizontalFlip(), T.RandomRotation(10),
                      T.ToTensor(), T.Normalize(MEAN, STD)])


def eval_tf(size=224):
    return T.Compose([T.Resize((size, size)), T.ToTensor(), T.Normalize(MEAN, STD)])


class ImageTable(Dataset):
    def __init__(self, df, root=".", tf=None, task="regression"):
        self.df, self.root, self.tf, self.task = df.reset_index(drop=True), root, tf or eval_tf(), task

    def __len__(self):
        return len(self.df)

    def __getitem__(self, i):
        r = self.df.iloc[i]
        img = Image.open(f"{self.root}/{r.image_path}").convert("RGB")
        y = r.label if self.task == "classification" else r.target
        return self.tf(img), torch.tensor(float(y)), i


def load_split(manifest, split_csv, split, label_site=None, task="regression"):
    """Rows of the manifest whose infant belongs to `split`.

    task="classification" (Mendeley) adds a `label` column with the severity class of the TcB reading:
    label_site "forehead" or "sternum" keeps only the images of that site and classifies that reading;
    label_site "mean" keeps all images and classifies the per-infant mean of the TcB readings.
    """
    m = pd.read_csv(manifest)
    s = pd.read_csv(split_csv)
    ids = set(s.loc[s.split == split, "infant_id"].astype(str))
    d = m[m.infant_id.astype(str).isin(ids)].copy()
    if task == "classification":
        if label_site in ("forehead", "sternum"):
            d = d[d.site.astype(str).str.lower().str.contains(label_site)].copy()
            d["label"] = severity(d.target)
        else:
            d["label"] = severity(d.groupby("infant_id").target.transform("mean"))
    return d
