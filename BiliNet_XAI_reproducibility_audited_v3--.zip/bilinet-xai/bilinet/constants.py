"""Constants shared by all scripts (no deep-learning dependencies)."""
import numpy as np
import pandas as pd

THRESHOLDS = (5.0, 12.0, 20.0)      # Normal < 5, Mild 5-12, Moderate 12-20, Severe > 20 mg/dL
CLASSES = ("Normal", "Mild", "Moderate", "Severe")


def severity(values):
    return np.digitize(np.asarray(values, dtype=float), THRESHOLDS)


def severity_label(value):
    """Severity class index (0-3) of a single bilirubin value in mg/dL."""
    return int(np.digitize(float(value), THRESHOLDS))


def infant_level(pred_df):
    """Average the image predictions of each infant (infant-level protocol of Tables 5 and 6)."""
    agg = {"y_true": "first", "y_pred": "mean"}
    if "fitzpatrick_group" in pred_df:
        agg["fitzpatrick_group"] = "first"
    return pred_df.groupby("infant_id", as_index=False).agg(agg)
