"""Regression and classification metrics (Eqs. 28-30) and the statistical procedures of Supplementary Section S5."""
import numpy as np
from scipy import stats
from sklearn.metrics import (accuracy_score, f1_score, precision_recall_fscore_support,
                             roc_auc_score)


def regression(y, p):
    y, p = np.asarray(y, float), np.asarray(p, float)
    e = y - p
    return {"MAE": float(np.abs(e).mean()), "RMSE": float(np.sqrt((e ** 2).mean())),
            "R2": float(1 - (e ** 2).sum() / ((y - y.mean()) ** 2).sum()), "rho": float(stats.pearsonr(y, p)[0])}


def classification(y_cls, p_cls, proba=None):
    out = {"Accuracy": accuracy_score(y_cls, p_cls), "F1_weighted": f1_score(y_cls, p_cls, average="weighted")}
    pr, rc, f1, sup = precision_recall_fscore_support(y_cls, p_cls, labels=range(4), zero_division=0)
    out["per_class"] = {"precision": pr, "recall": rc, "f1": f1, "support": sup}
    if proba is not None:
        out["AUC_weighted"] = roc_auc_score(y_cls, proba, multi_class="ovr", average="weighted", labels=range(4))
    return out


def wilcoxon_paired(err_a, err_b):
    """Paired Wilcoxon signed-rank test on per-infant absolute errors, plus matched-pairs rank-biserial r."""
    d = np.asarray(err_b, float) - np.asarray(err_a, float)
    res = stats.wilcoxon(err_a, err_b, zero_method="wilcox", alternative="two-sided")
    d = d[d != 0]
    ranks = stats.rankdata(np.abs(d))
    r = (ranks[d > 0].sum() - ranks[d < 0].sum()) / ranks.sum()
    return res.pvalue, r


def bonferroni(p, m):
    return min(1.0, p * m)


def bca_ci_mean_diff(err_a, err_b, n_boot=10000, seed=42, level=0.95):
    """BCa bootstrap CI on mean(err_a) - mean(err_b), resampling infants."""
    a, b = np.asarray(err_a, float), np.asarray(err_b, float)
    res = stats.bootstrap((a, b), lambda x, y: x.mean() - y.mean(), paired=True, vectorized=False,
                          n_resamples=n_boot, method="BCa", confidence_level=level,
                          random_state=np.random.default_rng(seed))
    return res.confidence_interval.low, res.confidence_interval.high


def bootstrap_ci_mae(err, n_boot=10000, seed=42, level=0.95):
    """Percentile bootstrap CI for an MAE (used for the image-level per-group intervals in Table 7)."""
    err = np.abs(np.asarray(err, float))
    res = stats.bootstrap((err,), np.mean, n_resamples=n_boot, method="percentile",
                          confidence_level=level, random_state=np.random.default_rng(seed))
    return res.confidence_interval.low, res.confidence_interval.high
