# BiliNet-XAI

Repository: https://github.com/ManalAlghieth/BiliNet-XAI

Reference implementation and reproducibility package for

> **BiliNet-XAI: A Multimodal Explainable Deep Learning Framework for Noninvasive Neonatal Bilirubin Estimation**
> (submitted to *Computers, Materials & Continua*).

The repository contains the model (dual-branch spectral-spatial attention transformer, DSSAT, with cross-modal gated fusion), the training objective including the Grad-CAM++ saliency-entropy term, the infant-level data splitting procedure, the baseline and ablation protocols, and the statistical analyses behind Tables 3 to 8 and Figures 4, 7, 8 and 9.

## Repository layout

| Path | Content |
|---|---|
| `bilinet/model.py` | Model, Eqs. (1)–(19); Table 5 variants via `build_model(variant)` |
| `bilinet/losses.py` | Eqs. (20)–(23) and L_xai (entropy of the L1-normalised spatial Grad-CAM++ map) |
| `bilinet/explain.py` | Grad-CAM++ on the spatial branch (Eqs. 24–26) and band-level spectral importance |
| `bilinet/metrics.py` | MAE, RMSE, R², Pearson ρ, classification metrics, Wilcoxon, rank-biserial r, Bonferroni, bootstrap intervals |
| `bilinet/data.py` | Manifest-based datasets, severity thresholds, infant-level aggregation |
| `scripts/make_manifest.py` | Converts each dataset's metadata into a standard manifest |
| `scripts/make_splits.py` | Infant-level 70/15/15 split stratified by severity, seed 42 |
| `scripts/pretrain_fitzpatrick.py` | Spectral-branch pretraining on Fitzpatrick17k |
| `scripts/train.py` | NeoJaundice regression training (Algorithm 1), per-epoch log for Fig. 4 |
| `scripts/predict.py` | NeoJaundice image-level and infant-level predictions, latency (Table 8) |
| `scripts/train_mendeley.py` | Mendeley classification training: BiliNet-XAI with a four-class cross-entropy head (`build_model("mendeley_cls")`), Table 4 |
| `scripts/predict_mendeley.py` | Mendeley image-level and infant-level classification predictions, ROC curve (Fig. 6b) |
| `scripts/train_baselines.py` | Table 6 baselines under the same protocol |
| `scripts/stats_tables.py` | Tables 3–8 from prediction files |
| `scripts/aggregate_seeds.py` | Per-seed and mean-ensemble metrics across seeds 0, 7, 42, 123 (Section 4.1.1) |
| `scripts/kfold_cv.py` | Infant-level 5-fold CV (severity × Fitzpatrick stratified) of BiliNet-XAI and baselines with per-fold and pooled paired tests; protocol listed as future work in Section 5, not used for reported results |
| `scripts/zero_shot_mendeley.py` | Zero-shot NeoJaundice → Mendeley evaluation of BiliNet-XAI and baselines without retraining; protocol listed as future work in Section 5, not used for reported results |
| `scripts/count_complexity.py` | Forward-pass cost in multiply–accumulate operations (1.24 G for the full model; Section 3.10, Tables 6 and 8) |
| `scripts/plot_curves.py`, `explain_figure.py`, `plot_tables.py` | Figures 3, 4, 7, 8 and 9 (Fig. 5b and 6b: `predict_mendeley.py`) |
| `configs/hyperparameters.yaml` | Table 2 |
| `splits/` | Split index files; see `splits/README.md` |
| `results/` | Prediction files and recomputed tables; see `results/README.md` |
| `run_all.sh` | End-to-end reproduction (all 8 steps) |

## Installation

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q tests        # shape, gradient and statistics checks
```

The supplied training scripts use a **single device** (`cuda` if available, otherwise CPU); they do not implement dual-GPU training or distributed data parallelism. The manuscript/supplement's claim of two NVIDIA A100 GPUs must be reconciled against the actual run logs before publication. The package archive itself contains no training logs or checkpoints.

## Data

All three datasets are public and must be downloaded from their original sources
(they are not redistributed here).

| Dataset | Use | Source |
|---|---|---|
| NeoJaundice (2,235 images, 745 infants) | Regression (TSB), main evaluation (Tables 3, 5–8) | https://doi.org/10.6084/m9.figshare.22302559 |
| Neonatal Jaundice Assessment — forehead and sternum (~600 images, 300 infants) | Complementary classification validation (Table 4) | https://data.mendeley.com/datasets/yfsz6c36vc/1 |
| Fitzpatrick17k (9,847 images used) | Spectral-branch pretraining only | https://github.com/mattgroh/fitzpatrick17k |

Place the datasets under `data/` as `data/NeoJaundice/`, `data/Mendeley/`, and
`data/fitzpatrick17k/`.  Then build the manifests with `scripts/make_manifest.py`,
passing the **exact column names** found in each dataset's metadata CSV.

> **Mendeley manifest**: one row per image and site; `--target-col` is the TcB reading of that
> site and `--site-col` identifies forehead or sternum. Set `--infant-col`, `--target-col` and
> `--site-col` in Step 1 of `run_all.sh` to the column headers of the downloaded `metadata.csv`.
> The severity label is the class of the per-infant mean of the forehead and sternum TcB readings
> (`--label-site mean`, the default; `forehead` and `sternum` select a single site).

## Reproducing the paper

```bash
bash run_all.sh
```

or step by step:

1. `make_manifest.py` builds `data/neojaundice_manifest.csv` and
   `data/mendeley_manifest.csv`.
2. `make_splits.py` creates `splits/neojaundice_splits.csv` (521/112/112 infants)
   and `splits/mendeley_splits.csv` (210/45/45 infants).  Every infant appears in
   exactly one partition.  The split is deterministic (seed 42).
3. `pretrain_fitzpatrick.py` trains the spectral branch for 6-class phototype
   classification (50 epochs, AdamW 1e-4) and saves `spectral.pt`.
4. `train.py` trains for 200 epochs with cosine annealing (seed 42 primary;
   seeds 0, 7, 123 for the seed analysis of Section 4.1.1).
5. `predict.py` writes `bilinet_test_image_predictions.csv` and
   `bilinet_test_infant_predictions.csv`, plus `efficiency_metrics.csv` (Table 8).
6. `predict.py` is run for each of the four seeds and `aggregate_seeds.py` reports
   the per-seed and mean ± SD MAE and R² (Section 4.1.1).
7. `train_mendeley.py` and `predict_mendeley.py` produce Table 4, Fig. 5b and Fig. 6b.
8. `stats_tables.py` recomputes tables from prediction files and, by default, enforces the documented
   test counts (NeoJaundice 336 images/112 infants; Mendeley 191 images/45 infants) and complete
   ablation/baseline prediction sets. It also computes NeoJaundice ROC/AUC using the documented
   negative distance-to-severity-interval ranking scores (not calibrated probabilities). `count_complexity.py`
   reports BiliNet-XAI MACs. `profile_baselines.py` optionally profiles timm baselines at 224x224
   (requires fvcore).
9. Optional (`RUN_EXTRA=1 bash run_all.sh`): `kfold_cv.py` and `zero_shot_mendeley.py`. These are
   additional experiments, not completed results until the commands have been run and outputs archived. For the
   zero-shot regression against TSB, pass the Mendeley TSB column with `--tsb-col` in Step 1.

### Evaluation units

* **Infant level** (Tables 5, 6 — headline regression metrics): the predictions of
  an infant's images are averaged, then the error is computed.  Wilcoxon tests pair infants
  (n = 112).
* **Image level** (Tables 3 and 4, Table 7 Fitzpatrick rows, image-level overall row):
  errors are computed per image.  Bootstrap intervals are over images and do
  not account for within-infant correlation.

### Statistics

* Table 6: paired Wilcoxon signed-rank tests on per-infant absolute errors,
  Bonferroni correction for ten comparisons, BCa bootstrap 95% intervals
  (10,000 resamples) on the MAE difference.
* Table 5: same test, Bonferroni correction for five comparisons.
* Table 7: percentile bootstrap 95% intervals for each group MAE
  (10,000 resamples, image level).

### Explainability

Grad-CAM++ is applied to the spatial branch: the 196 spatial tokens are
reshaped to 14 × 14 and passed through an identity-initialised 1 × 1
convolution.  The same L1-normalised map defines L_xai during training.
The spectral branch is explained with band-level importance (normalised L1
gradient magnitude per pseudo-spectral token).

### Parameter count

`ffn_dim = 2048`. Trainable counts: 11.27 M (full), 5.30 M (spectral only),
5.30 M (RGB tokens), 5.61 M (spatial only), 11.01 M (no gating).
Run `python tests/test_model.py` to print them.

## Baselines

General backbones are taken from `timm` with ImageNet weights and a
one-output regression head.  ViT-NeoJaundice uses a ViT-B/16 backbone.
Eliazer ViT-KELM uses fine-tuned ViT-B/16 features followed by kernel
extreme learning machine regression. **CMAF-Net is not implemented in this archive**:
`scripts/baselines_custom.py` is an explicit placeholder. Do not report it as a trained
baseline or claim a ten-baseline comparison until a fully specified adaptation is supplied.
The original CMAF-Net is a four-modality 3D MRI segmentation model, not a ready-made
single-RGB regression backbone.

## Citation

If you use this code, please cite the paper once it is published (citation
details will be added on acceptance).

## Code and data availability

Code is archived at https://github.com/ManalAlghieth/BiliNet-XAI. The datasets are
public and are obtained from the sources listed under "Data".

## License

MIT — see `LICENSE`.

## Reproducibility status

See [`REPRODUCIBILITY_AUDIT.md`](REPRODUCIBILITY_AUDIT.md) for known manuscript/package discrepancies,
software repairs, required real-data runs, and items that remain unresolved. The ZIP as supplied
does not include the datasets, prediction files, checkpoints, logs, tables or figures; therefore it is
not sufficient by itself to regenerate the manuscript's numerical claims.

### Optional baseline profiler

Install `fvcore` separately and run `python scripts/profile_baselines.py`. The output uses fvcore's FLOP-counting convention for 224x224 inputs; it is not a latency benchmark and should not be mixed with MAC counts from a different convention. Unsupported operators are included in the output CSV for review.
