# Reviewer action matrix (based on the checklist supplied in the request)

No separate reviewer-report file was included among the three uploads. This matrix maps the supplied checklist to the available code and the action required.

| Reviewer requirement / checklist item | Current package state | What is required for a defensible response | Can be completed from supplied ZIP alone? |
|---|---|---|---|
| Five-fold infant-level CV | Script exists; no fold data/results | Run all five folds on the real NeoJaundice manifest; archive fold assignments, checkpoints, per-fold predictions and summary. Report mean/SD and fold-level uncertainty; do not substitute the existing single split. | No |
| Zero-shot NeoJaundice→Mendeley | Script exists; no NeoJaundice checkpoint or Mendeley manifest | Freeze the NeoJaundice checkpoint; evaluate Mendeley without tuning; reconcile 191-image/45-infant count and define the label reference as TcB. | No |
| Mendeley baselines | Supplement explicitly says none were evaluated | Train the requested baselines using the identical Mendeley split/protocol, with infant-grouped evaluation and TcB labels. Clearly distinguish internal validation from zero-shot transfer. | No |
| Correct Table 3 / Fig. 5(a) | Prediction files absent; manuscript counts 495 vs documented 336 | Re-run seed-42 prediction; require 336 images/112 infants; rebuild confusion matrix and all metrics. | No |
| Correct Fig. 3(a) | Logs absent; code writes MSE=RMSE² | Re-run or recover original validation log; verify MSE >= MAE² for each epoch; regenerate figure. | No |
| Fig. 6(a) ROC / AUC | No NeoJaundice ROC implementation in original archive | Recompute from real regression outputs using the explicit interval-distance score mapping now added; report these as derived ranking scores, not class probabilities. | Code: yes; numeric curves: no |
| Table 6 CIs | Prediction files absent | Recompute 10,000 paired BCa resamples on 112 infant-level error pairs using seed 42; retain unrounded output. | No |
| CMAF-Net baseline | Placeholder only | Either implement and fully document a justified adaptation from the original 3D multimodal MRI model, then retrain, or remove it and revise the baseline count and all claims that depend on it. | No |
| Baseline GFLOPs | No baseline profiler in original archive | Run the added fvcore profiler at 224x224; document profiler convention, unsupported ops and version. Profile any custom models separately. | Code: yes; numeric results: requires environment |
| GPU count | Code uses one CUDA device | Correct manuscript/supplement to single-GPU unless contemporaneous run logs prove otherwise; alternatively implement DDP and rerun. | Documentation correction: yes |
