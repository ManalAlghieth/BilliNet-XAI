# Results directory

This directory is intentionally empty in the supplied archive. The manuscript's numerical outputs cannot be reconstructed until the public datasets are downloaded and the experiments are run.

Expected outputs include:

- `bilinet_test_image_predictions.csv`, `bilinet_test_infant_predictions.csv`
- five ablation prediction pairs
- ten baseline prediction pairs (only after CMAF-Net is genuinely implemented and trained)
- Mendeley classification predictions and logits
- training logs and checkpoints under `runs/`
- generated `tables/` and `figures/`

Run `scripts/stats_tables.py --results results` only after prediction files are present. By default it enforces the manuscript's documented NeoJaundice count (336 images/112 infants), Mendeley count (191 images/45 infants), all five ablations and all ten baselines. The diagnostic flags `--allow-count-mismatch` and `--allow-partial` must not be used for final manuscript results.

NeoJaundice ROC scores are explicitly defined in `scripts/stats_tables.py` as negative distances from each continuous TSB prediction to each severity interval. They are derived ranking scores, not calibrated class probabilities. The generated ROC figure and points CSV are saved as `figures/neojaundice_roc.png` and `figures/neojaundice_roc_points.csv`.
