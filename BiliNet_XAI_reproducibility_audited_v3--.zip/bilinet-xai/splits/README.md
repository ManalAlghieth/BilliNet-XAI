# Split index files

`scripts/make_splits.py` (seed 42, infant-level 70/15/15, stratified by severity class) writes the split files here
when step 2 of `run_all.sh` is run. They are generated deterministically from the public dataset metadata, so no
split file needs to be distributed.

| File | Contents |
|---|---|
| `neojaundice_splits.csv` | infant_id, split (train/val/test), severity: 521/112/112 infants |
| `mendeley_splits.csv` | infant_id, split (train/val/test), severity: 210/45/45 infants; severity from the per-infant mean TcB reading |
| `fitz17k_subset.csv` | image_path, fitzpatrick_group: the 9,847-image Fitzpatrick17k pretraining subset (written by `pretrain_fitzpatrick.py`) |

All images of an infant appear in exactly one partition.
